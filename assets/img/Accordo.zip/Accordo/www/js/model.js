let listaCanali=[];
let listaPost =[];

class Model{

//METODI PER LA BACHECA
addCanale(canale){
    listaCanali.push(canale);
  }

svuotaCanali(){
    listaCanali=[];
  }

getListaCanali(){
    return listaCanali;
  }


//----------------------------------------------//


//METODI PER I POST
 addPost(post){
     listaPost.push(post);
 }
 svuotaPost(){
     listaPost=[];
 }

 getListaPost(){
     return listaPost;
 }

 setListaPost(lista){
   listaPost=lista;
 }

 getImgPostByIndex(index){
   return listaPost[index].imgPost;
 }
 
 //----------------------------------------------//


}

function setModel(model) {
    this.model = model;
}

function getInstance() {
    return model;
}
