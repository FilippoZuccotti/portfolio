//CHIAMATA DI RETE PER PRENDERE IL SID
function register(){
  $(function() {
    $.ajax({
       method: 'GET',
       url:"https://ewserver.di.unimi.it/mobicomp/accordo/register.php",
       success: function(result) {
        let obj=JSON.parse(result);
        sid=obj.sid;
        setProfile();
       },
       error: function(error) {
        console.error(error);
        }
  });
  });
}

//CHIAMATA DI RETE PER SETTARE IL PROFILO CON I NOSTRI DATI
function setProfile(){

let JsonObject={};
let pagina=localStorage.getItem("pagina");

if(pagina=="profilo"){

  let sid=localStorage.getItem("sid");
  let dati=controllaDati();

  switch (dati) {
    case 2:
      JsonObject={
        sid: sid,
        name: document.getElementById("usernameProfilo").value,
        picture: imageBase64
      }
      break;
    case 1:
      JsonObject={
        sid: sid,
        name: localStorage.getItem("name"),
        picture: imageBase64
      }
      break;
    case 0:
      JsonObject={
        sid: sid,
        name: document.getElementById("usernameProfilo").value,
        picture: localStorage.getItem("picture")
      }
      break;

  }

} else{

  if(username=="" && fotoProfilo==true){
    JsonObject={
      sid: sid,
      name: null,
      picture: imageBase64
    }
  } else if(username!="" && fotoProfilo==false){
    JsonObject={
      sid: sid,
      name: username,
      picture: null
    }
  } else{
    JsonObject={
      sid: sid,
      name: username,
      picture: imageBase64
    }
  }

}


    $.ajax({
        type: "POST",
        url: "https://ewserver.di.unimi.it/mobicomp/accordo/setProfile.php",
        dataType: 'json',
        data: JSON.stringify(JsonObject),
        success: function (result) {

          let pagina=localStorage.getItem("pagina");

          if(pagina=="profilo"){


          errorAlert("Hai aggiornato il profilo correttamente!");

            let dati=controllaDati();



            switch (dati) {
              case 2:
                localStorage.setItem('name', document.getElementById("usernameProfilo").value);
                localStorage.setItem('picture', imageBase64);
              case 1:
                localStorage.setItem('picture', imageBase64);
              case 0:
                localStorage.setItem('name', document.getElementById("usernameProfilo").value);

            }

            $("#profilo").hide();
            $("#bacheca").show();
            localStorage.setItem("pagina", "bacheca");
            rilevaPagina();

          }else{

            errorAlert("La registrazione è andata a buon fine");

            localStorage.setItem('sid', sid);
            localStorage.setItem('name', username);
            localStorage.setItem('picture', imageBase64);
            localStorage.setItem('pagina', "bacheca");
            $("#registrazione").hide();
            $("#bacheca").show();
            rilevaPagina();

            let obj=[];
            localStorage.setItem("fotoPost", JSON.stringify(obj));
            localStorage.setItem("fotoProfilo", JSON.stringify(obj));

          }

        },
        statusCode: {
            413: function () {
                errorAlert("Seleziona un'immagine più piccola");
            },
            400: function () {
              errorAlert("Username già esistente");
            }
        },
        error: function (error) {
            console.error(error);
        }
    });

}

//CHIAMATA DI RETE CHE SCARICA TUTTI I CANALI
function scaricaCanali(){
  console.log("ok sono entrato");

  document.getElementById("contenitoreBacheca").innerHTML="";
  getInstance().svuotaCanali();

  let sid=localStorage.getItem("sid");


let JsonObject={};
JsonObject={
  sid: sid
}

$.ajax({
    type: "POST",
    url: "https://ewserver.di.unimi.it/mobicomp/accordo/getWall.php",
    dataType: 'json',
    data: JSON.stringify(JsonObject),
    success: function (result) {
      let arrayCanali=result.channels;

      for(i=0;i<arrayCanali.length;i++){
        let channel=arrayCanali[i];


        let ctitle=channel.ctitle;
        let mine=channel.mine;

        let singleChannel=new Channel(ctitle, mine);

        getInstance().addCanale(channel);



      }

      caricaCanali();

    },
    error: function (error) {
        console.error(error);
    }
});

}

//CHIAMATA DI RETE CHE PERMETTE DI CREARE UN NUOVO CANALE
function addChannel(titolocanale){

  let sid=localStorage.getItem("sid");

  let JsonObject={
    sid: sid,
    ctitle: titolocanale
  }

  $.ajax({
      type: "POST",
      url: "https://ewserver.di.unimi.it/mobicomp/accordo/addChannel.php",
      dataType: 'json',
      data: JSON.stringify(JsonObject),
      success: function (result) {
        $("#annullaCanale").click();
        errorAlert("Canale aggiunto");
        document.getElementById("contenitoreBacheca").innerHTML="";
        document.getElementById("textCanale").value="";
        scaricaCanali();
      },
      statusCode: {
          400: function () {
              errorAlert("Canale già esistente");
          }
      },
      error: function (error) {
          console.error(error);
      }
  });

}

//METODO CHE PERMETTE DI SCARICARE TUTTI I POST DI UN SINGOLO CANALE
function scaricaPost(titolo){


    getInstance().svuotaPost();

    let sid=localStorage.getItem("sid");
    let postImmagine= 0;
    let immagineProfilo=0;
    let JsonObject={
      sid: sid,
      ctitle: titolo
    }
    $.ajax({
        type: "POST",
        url: "https://ewserver.di.unimi.it/mobicomp/accordo/getChannel.php",
        dataType: 'json',
        data: JSON.stringify(JsonObject),
        success: function (result) {
          let arrayPost=result.posts;

          if(arrayPost.length==0){
            errorAlert("Il canale è vuoto");
          }


          for(i=0;i<arrayPost.length;i++){
            var post;
            let tipo= arrayPost[i].type;
            let uid = arrayPost[i].uid;
            let name= arrayPost[i].name;
            let pversion= arrayPost[i].pversion;
            let pid = arrayPost[i].pid;

            if(pversion!=0){
              immagineProfilo++;
            }

            switch (tipo) {
                case "t":
                    let content = arrayPost[i].content;
                    post = new Post(uid,name,pversion,pid,tipo,content,"","","","");
                    getInstance().addPost(post);
                    break;
                case "i":
                     postImmagine++;
                     post = new Post(uid,name,pversion,pid,tipo,"","","","","");
                     getInstance().addPost(post);
                     break;
                case "l":
                    let lat =  arrayPost[i].lat;
                    let lon =  arrayPost[i].lon;
                    post = new Post(uid,name,pversion,pid,tipo,"posizione condivisa",lat,lon,"","");
                    getInstance().addPost(post);
                    break;
            }


          }

        caricaFotoPost(postImmagine, immagineProfilo);

        },
        error: function (error) {
            console.error(error);
        }
    });
}

//CHIAMATA DI RETE PER SCARICARE TUTTI I POST DI TIPO IMMAGINE
function caricaFotoPost(postImmagine, immagineProfilo){

  console.log("post di tipo immagine: "+postImmagine);

  var sid=localStorage.getItem("sid");
  var lista_post = getInstance().getListaPost();

    if(postImmagine==0){
        console.log("non ci sono post di tipo immagine");
        scaricaFotoProfilo(immagineProfilo);
        caricaPost();
        return;
    }else{

        var fotoPost=JSON.parse(localStorage.getItem("fotoPost"));
        var conteggioPostImmagine=0;

        for(i=0;i<lista_post.length;i++){
          var fotoPresente=false;

          if(lista_post[i].type=="i"){

            for(j=0;j<fotoPost.length;j++){
              let currentPost=fotoPost[j];

              if(lista_post[i].pid==currentPost.pid){
                //immagine già presente nel db aggiorniamo il model
                let content=currentPost.content;
                lista_post[i].imgPost=content;
                conteggioPostImmagine++;
                fotoPresente=true;
                break;

              }
            }

            if(fotoPresente==false){
              //l'immagine non è presente nel db quindi faccio la chiamata

              let pid=lista_post[i].pid;

              var JsonObject={
                sid: sid,
                pid: pid
              }

              $.ajax({
                  type: "POST",
                  url: "https://ewserver.di.unimi.it/mobicomp/accordo/getPostImage.php",
                  dataType: 'json',
                  data: JSON.stringify(JsonObject),
                  async: false,
                  success: function (result) {
                      let pid=result.pid;
                      let content=result.content;
                      fotoPost.push({"pid":pid, "content":content});
                      lista_post[i].imgPost=content;
                      conteggioPostImmagine++;
                  },
                  error: function (error) {
                      console.error(error);
                  }
              });

            }


            if(conteggioPostImmagine==postImmagine){
              localStorage.setItem("fotoPost", JSON.stringify(fotoPost));
              getInstance().setListaPost(lista_post);
              scaricaFotoProfilo(immagineProfilo);
              caricaPost();
              return;
            }



          }

        }

    }

}


//CHIAMATA DI RETE PER SCARICARE TUTTE LE IMMAGINI DI PROFILO DEGLI UTENTI CHE HANNO INSERITO POST ALL'INTERNO DI UN SINGOLO CANALE
function scaricaFotoProfilo(immagineProfilo){

  if(immagineProfilo==0){
    console.log("Non ci sono immagini di profilo")
  }else{

    var listaPost = getInstance().getListaPost();
    var sid=localStorage.getItem("sid");
    var conteggioFotoProfilo=0;
    var fotoProfilo=JSON.parse(localStorage.getItem("fotoProfilo"));

    for(i=0;i<listaPost.length;i++){

      var fotoPresente=false;

      if(listaPost[i].pversion!=0){

        var currentPost=listaPost[i];
        var uid=currentPost.uid;
        var pversion=currentPost.pversion;


          for(j=0;j<fotoProfilo.length;j++){

            if(fotoProfilo[j].uid==uid && fotoProfilo[j].pversion==pversion){
              fotoPresente=true;
              //immagine recente già nel db aggiorno solo il model
              let picture=fotoProfilo[j].picture;
              listaPost[i].imgProfilo=picture;
              conteggioFotoProfilo++;
              break;
            }else if(fotoProfilo[j].uid==uid && fotoProfilo[j].pversion!=pversion){
              fotoPresente=true;
              //immagine nel db vecchia faccio la chiamata e aggiorno con la nuova

              var JsonObject={
                sid: sid,
                uid: uid
              }

              $.ajax({
                  type: "POST",
                  url: "https://ewserver.di.unimi.it/mobicomp/accordo/getUserPicture.php",
                  dataType: 'json',
                  data: JSON.stringify(JsonObject),
                  async: false,
                  success: function (result) {
                      let picture=result.picture;
                      let pversion=result.pversion;
                      listaPost[i].imgProfilo=picture;
                      fotoProfilo[j].pversion=pversion;
                      fotoProfilo[j].picture=picture;
                      conteggioFotoProfilo++;
                  },
                  error: function (error) {
                      console.error(error);
                  }
              });

              break;
            }

          }

          //AGGIUNGO L'IMMAGINE PER LA PRIMA VOLTA PERCHE' E' NUOVA
          if(fotoPresente==false){


            var JsonObject={
              sid: sid,
              uid: uid
            }

            $.ajax({
                type: "POST",
                url: "https://ewserver.di.unimi.it/mobicomp/accordo/getUserPicture.php",
                dataType: 'json',
                data: JSON.stringify(JsonObject),
                async: false,
                success: function (result) {
                    let picture=result.picture;
                    listaPost[i].imgProfilo=picture;
                    fotoProfilo.push({"uid":uid, "pversion":pversion, "picture":picture});
                    conteggioFotoProfilo++;
                },
                error: function (error) {
                    console.error(error);
                }
            });

          }
          /////////////////////////////////////////////////////////////////////////////////


        if(conteggioFotoProfilo==immagineProfilo){
          localStorage.setItem("fotoProfilo", JSON.stringify(fotoProfilo));
          getInstance().setListaPost(listaPost);
          return;
        }


      }

    }

  }



}

//CHIAMATA DI RETE PER AGGIUNGERE UN NUOVO POST ALL'INTERNO DI UN CANALE
function addPost(type){

  var sid=localStorage.getItem("sid");
  var ctitle=titolo;
  var content;


  if(type=="t"){
    content=document.getElementById("textPost").value;
}else if(type=="i"){
    content=imageBase64;
}

  let JsonObject={};

  if(type=="t" || type=="i"){

    JsonObject={
      sid: sid,
      ctitle: ctitle,
      type: type,
      content: content
    }

  }else{

    JsonObject={
      sid: sid,
      ctitle: ctitle,
      type: type,
      lat: lat,
      lon: lon
    }

  }

      $.ajax({
          type: "POST",
          url: "https://ewserver.di.unimi.it/mobicomp/accordo/addPost.php",
          dataType: 'json',
          data: JSON.stringify(JsonObject),
          success: function (result) {
            console.log("post aggiunto");
            document.getElementById("textPost").value="";
            document.getElementById("divPost").innerHTML="";
            scaricaPost(ctitle);
          },
          statusCode: {
              413: function () {
                  errorAlert("Seleziona un'immagine più piccola");
              }
          },
          error: function (error) {
              console.error(error);
          }
      });

}
