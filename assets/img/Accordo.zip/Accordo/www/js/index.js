var imageBase64;
var fotoProfilo=false;
var sid;
var username;
var titolo;
var lat;
var lon;
var cutImage;

//AVVIO DELL'APPLICAZIONE
$(function(){

  console.log("Sito avviato");
  let model=new Model();
  setModel(model);

  $("#registrazione").hide();
  $("#bacheca").hide();
  $("#contenitorePost").hide();
  $("#mappa").hide();
  $("#foto").hide();
  $("#profilo").hide();
  $("#ritaglia").hide();


  if(localStorage.getItem("sid")){
    //l'utente è già registrato
    localStorage.setItem("pagina", "bacheca");
    rilevaPagina();
    $("#bacheca").show();
  } else{
    //primo primo_accesso
    $("#registrazione").show();
    localStorage.setItem("pagina", "registrazione");
  }

});

//METODI DA RICHIAMARE IN BASE ALLA PAGINA IN CUI CI TROVIAMO
function rilevaPagina(){

  let pagina=localStorage.getItem("pagina");

  switch(pagina){
    case "bacheca":
      scaricaCanali();
      break;
    case "canale":
      scaricaPost(titolo);
      break;
    case "profilo":
      caricaDati();
      break;
  }

}

//METODI RICHIAMATI AL CLICK DEI BOTTONI
$(function(){

  //  SCHIACCIANDO SUL BOTTONE CONFERMA L'UTENTE SI REGISTRA ALLA PIATTAFORMA
  $("#btnConfermaRegistrazione").click(function() {
    username=""+document.getElementById('username').value;

    if(username=="" && fotoProfilo==false){
      errorAlert("Devi inserire almeno un campo");
    } else{
      register();
    }

  });

  //  SCHIACCIANDO SUL BOTTONE AGGIORNA L'UTENTE MODIFICA IL PROPRIO PROFILO
  $("#btnConfermaProfilo").click(function() {

    let oldUsername=localStorage.getItem("name");
    let oldPicture=localStorage.getItem("picture");
    let newUsername=document.getElementById("usernameProfilo").value;
    let picture=document.getElementById("immagineAggiornaProfilo").src;
    //let newPicture=picture.replace("data:image/jpeg;base64,", "");
    let newPicture=imageBase64;

    console.log("oldUsername: "+oldUsername);
    console.log("oldPicture: "+oldPicture.substr(0,50));
    console.log("newUsername: "+newUsername);
    console.log("newPicture: "+newPicture);

    if(newPicture==undefined){
      newPicture="undefined";
    }


    if(oldUsername==newUsername && newPicture==oldPicture){
      errorAlert("Devi cambiare almeno uno dei due parametri");
    } else{
      if(newUsername.length==0 || newUsername.length>20){
        errorAlert("Controlla la lunghezza del nome");
      }else{
        setProfile();
      }
    }


  });

  //SCHIACCIANDO SUL BOTTONE CARICA IMMAGINE VIENE APERTA LA GALLERIA E CARICATA L'IMMAGINE DOPO AVERLA RITAGLIATA
  $("#btnCaricaImmagine").click(function() {
    load();
  });


  $("#labelImmagine").click(function(){
    $("#fileImage").click();
  });

  $("#labelImmagineProfilo").click(function(){
    $("#fileImageProfilo").click();
  });

  $("#iconAddChannel").click(function(){
    $("#bottone").click();
  });

  $("#iconProfilo").click(function(){
    $("#bacheca").hide();
    $("#profilo").show();
    localStorage.setItem("pagina", "profilo");
    rilevaPagina();
  });

  $("#imageIcon").click(function(){
    $("#aggImg").click();
  });

  $("#positionIcon").click(function(){
    getCurrentPosition();
  });

  $("#sendIcon").click(function(){
    let text=""+document.getElementById("textPost").value;

    if(text.length>0 && text.length<100){
      addPost("t");
    }else{
      errorAlert("Controlla il testo");
    }

  });

  $("#iconBachecaProfilo").click(function(){

      $("#profilo").hide();
      $("#bacheca").show();
      localStorage.setItem("pagina", "bacheca");
      rilevaPagina();

  });

  $("#creaCanale").click(function(){

    let titoloCanale=""+document.getElementById('textCanale').value;

    if(titoloCanale.length>0 && titoloCanale.length<=20){
      addChannel(titoloCanale);
    } else{
      errorAlert("Massimo 20 caratteri");
    }

  });

  $("#annullaCanale").click(function(){

    document.getElementById('textCanale').value="";

  });


  $("#backNavigation").click(function(){

        $("#contenitorePost").hide();
        $("#bacheca").show();
        localStorage.setItem("pagina","bacheca");
        rilevaPagina();
  });

  $("#backNavigationFoto").click(function() {
    $("#foto").hide();
    $("#contenitorePost").show();
    localStorage.setItem("pagina","canale");
  });

  $("#backNavigationMappa").click(function() {
    $("#mappa").hide();
    $("#contenitorePost").show();
    localStorage.setItem("pagina","canale");
  });

  $("#backNavigationRitaglia").click(function() {
    let pagina=localStorage.getItem("pagina");
    $("#ritaglia").hide();

    if(pagina=="profilo"){
      $("#profilo").show();
    }else{
      $("#registrazione").show();
    }
    document.getElementById("box").innerHTML="";
  });

  $("#btnSalva").click(function() {
    cutImage.croppie('result', 'base64').then(function(base64){
      if(confirm("Vuoi salvare l'immagine?")){


        if(localStorage.getItem("pagina")=="profilo"){
          document.getElementById("immagineAggiornaProfilo").src=base64;
          $("#profilo").show();
        }else{
          document.getElementById("profiloRegistrazione").src=base64;
          $("#registrazione").show();
        }

        $("#ritaglia").hide();
        var correctBase64;

        if(base64.includes("jpeg")){
          correctBase64=base64.replace("data:image/jpeg;base64,", "");
        }else{
          correctBase64=base64.replace("data:image/png;base64,", "");
        }

        var finalBase64=correctBase64.replace("\n", "");
        imageBase64=finalBase64;
        fotoProfilo=true;
        document.getElementById("box").innerHTML="";
      }

    });
  });


});

//DECODIFICA L'IMMAGINE DI PROFILO SCELTA AL MOMENTO DELLA REGISTRAZIONE E LA INSERISCE ALL'INTERNO DEL TAG IMG
function decodeRegistrationImage(event) {
  var selectedFile = event.target.files[0];
  var reader = new FileReader();
  var pagina=localStorage.getItem("pagina");
  var imgtag;

  if(pagina=="profilo"){
    imgtag = document.getElementById("immagineAggiornaProfilo");
  }else{
    imgtag = document.getElementById("profiloRegistrazione");
  }

  imgtag.title = selectedFile.name;

  reader.onload = function(event) {

    var base64=event.target.result;

    if(pagina=="profilo"){
      $("#profilo").hide();
    }else{
      $("#registrazione").hide();
    }

    $("#ritaglia").show();
    var image=document.createElement("img");
    image.src=base64;
    image.id="newImage";
    document.getElementById("box").appendChild(image);

    cutImage=$("#newImage").croppie({
      viewport:{
        width:100,
        height:100
      }
    });
  };

  reader.readAsDataURL(selectedFile);
}

//METODO CHE VIENE RICHIAMATO QUANDO SI SCHIACCIA SUL BOTTONE PER AGGIUNGERE UN POST DI TIPO IMMAGINE
function aggiungiFotoPost(event){
    console.log("sei entrato nel aggiungi foto post");
    var selectedFile = event.target.files[0];
    var tipo=selectedFile.type;
    var reader = new FileReader();

    reader.onload = function(event) {
      var base64 = event.target.result;
      var correctBase64;
      if(tipo=="image/jpeg"){
            correctBase64=base64.replace("data:image/jpeg;base64,", "")
      }else{
            correctBase64=base64.replace("data:image/png;base64,", "");
        }
      var finalBase64=correctBase64.replace("\n", "");
      imageBase64= finalBase64;
      if( confirm("vuoi aggiungere questa immagine?")){
          addPost("i");
      }


      document.getElementById("aggImg").value="";
    };

    reader.readAsDataURL(selectedFile);

}

//METODO CHE VIENE RICHIAMATO QUANDO SI SCHIACCIA SU UN SINGOLO CANALE NELLA BACHECA
function toSingleChannel(titoloP){
    document.getElementById("titleChannel").innerHTML="";
    document.getElementById("divPost").innerHTML="";
    titolo= titoloP;
    $("#bacheca").hide();
    $("#contenitorePost").show();
    document.getElementById("titleChannel").innerHTML=titolo;
    localStorage.setItem("pagina","canale");
    rilevaPagina();
}

//METODO CHE VIENE RICHIAMATO QUANDO SI SCHIACCIA SUL BOTTONE PER AGGIUNGERE UN POST DI TIPO POSIZIONE
function getCurrentPosition(){

  var options = {
      enableHighAccuracy: true
  }

  if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(successPosition, failPosition, options);
  }

}

function successPosition(position) {
    console.log("Posizione calcolata correttamente");

    lat = position.coords.latitude;
    lon = position.coords.longitude;

    if(confirm("Vuoi condividere la posizione?")){
      addPost("l");
    }
}

function failPosition(error) {
    console.error("Errore nel calcolare la posizione: "+error);
}


//METODO CHE VIENE RICHIAMATO OGNI VOLTA CHE SI ENTRA IN UN POST DI TIPO POSIZIONE PER VISUALIZZARE CORRETTAMENTE LA MAPPA
function visualizzaMappa(lat,lon){
    $("#contenitorePost").hide();
    $("#mappa").show();
    localStorage.setItem("pagina", "mappa");
    caricaCoordinate(lat,lon);
}

//METODO CHE VIENE RICHIAMATO QUANDO CI SPOSTIAMO ALLA PAGINA DEL POST IMMAGINE PER VISUALIZZARE LA FOTO A TUTTO SCHERMO
function visualizzaFoto(index){
    let imgPost=getInstance().getImgPostByIndex(index);
    $("#contenitorePost").hide();
    $("#foto").show();
    localStorage.setItem("pagina", "foto");
    let immagine=document.getElementById("imgGrande");
    let correctImage;

      try{
        window.atob(imgPost);
        correctImage="data:image/jpeg;base64,"+imgPost;
      }catch(e){
        console.log("errore nella decodifica: "+e);
        correctImage="img/immaginerrore.png";
      }

      immagine.src=correctImage;
}

//METODO CHE VIENE RICHIAMATO QUANDO CI SI SPOSTA ALLA PAGINA MODIFICA PROFILO PER VISUALIZZARE CORRETTAMENTE I NOSTRI DATI CORRENTI
function caricaDati(){



    var nome = localStorage.getItem("name");
    var base64 = localStorage.getItem("picture");
    var immagine=document.getElementById("immagineAggiornaProfilo");
    immagine.innerHTML="";

    if(nome!=="undefined" && base64!=="undefined"){
        document.getElementById("usernameProfilo").value = nome;
        immagine.src="data:image/jpeg;base64,"+base64;

    }else if(nome=="undefined"){
        immagine.src="data:image/jpeg;base64,"+base64;
    }else{
        document.getElementById("usernameProfilo").value = nome;
        immagine.src="img/profilo.png";
    }


}

//FUNZIONE CHE VIENE RICHIAMATA QUANDO AGGIORNIAMO IL PROFILO PER VEDERE QUALI PARAMETRI SONO STATI CAMBIATI
function controllaDati(){

  let oldUsername=localStorage.getItem("name");
  let oldPicture=localStorage.getItem("picture");
  let newUsername=document.getElementById("usernameProfilo").value;
  let newPicture=imageBase64;

  if(oldUsername!=newUsername && oldPicture!=newPicture){
    return 2;
  }else if(oldUsername==newUsername && oldPicture!=newPicture){
    return 1;
  }else{
    return 0;
  }

}

//METODO CHE PERMETTE DI CARICARE DINAMICAMENTE I CANALI ALL'INTERNO DELLA BACHECA
function caricaCanali(){

  let listaCanali=getInstance().getListaCanali();

  for(i=0;i<listaCanali.length;i++){

    if(listaCanali[i].mine=="t"){
        var nameC=""+ listaCanali[i].ctitle;
      let cardCanale="<div class='card' id='cardCanaleMine'  onClick='toSingleChannel(\""+ nameC + "\")'><div class='card-body'>"+listaCanali[i].ctitle+"</div></div>";
      $("#contenitoreBacheca").append(cardCanale);
    }else{
        var nameC=""+ listaCanali[i].ctitle;

      let cardCanale="<div class='card' id='cardCanale' name='"+nameC+"' onclick='toSingleChannel(\""+ nameC + "\")'><div class='card-body'>"+nameC+"</div></div>";
      $("#contenitoreBacheca").append(cardCanale);

    }

  }


}

function errorAlert(message) {
    alert(message);
}

//METODO CHE PERMETTE DI CARICARE DINAMICAMENTE I POST ALL'INTERNO DI UN SINGOLO CANALE
function caricaPost(){


    var listaPost = getInstance().getListaPost();

    for(i=0;i<listaPost.length;i++){

        var tipo = listaPost[i].type;
        var contentImage=listaPost[i].imgPost;
        var pversion=listaPost[i].pversion;
        var profileImage=listaPost[i].imgProfilo;
        var correctProfileImage;


        //CONTROLLO SE L'UTENTE HA UN'IMMAGINE DI PROFILO E SE E' DECODIFICATA CORRETTAMENTE ALTRIMENTI VISUALIZZO L'ICONA PROFILO DI DEFAULT
        if(pversion!=0){
          try{
            window.atob(profileImage);
            correctProfileImage="data:image/png;base64,"+profileImage;
          }catch(e){
            console.log("errore nella decodifica: "+e);
            correctProfileImage="img/profilo.png";
          }
        } else{
          correctProfileImage="img/profilo.png";
        }

        if(tipo=="t"){

          let cardPost =   "<div class='card'>"+
                            "<div class='card-body'>"+
                                "<p id='testoPost' class='card-text'>"+listaPost[i].content+"</p>"+
                                "<hr>"+
                            "<div id='contenitoreDatiPost' class='row'>"+
                            "<div class = 'col-3 col-md-1'>"+
                                 "<img src='"+correctProfileImage+"' id='imgProfiloPost' class='rounded-circle'>"+
                             "</div>"+
                             "<div class = 'col-9 col-md-11'> "+
                                 "<p id='autorePost' class='card-text'> Post di "+listaPost[i].name+"</p>"+
                             "</div>"+
                             "</div>"+
                             "</div>"+
                             "</div><br>";
                             $("#divPost").append(cardPost);

        } else if (tipo=="i") {

          let correctImage;


            try{
              window.atob(contentImage);
              correctImage="data:image/jpeg;base64,"+contentImage;
            }catch(e){
              console.log("errore nella decodifica: "+e);
              correctImage="img/immaginerrore.png";
            }

            let cardPostI =   "<div class='card' onClick='visualizzaFoto("+i+")' style='cursor:pointer;'>"+
                              "<div class='card-body'>"+
                                  "<img src='"+correctImage+"' id='imgPost'>"+
                                  "<hr>"+
                              "<div id='contenitoreDatiPost' class='row'>"+
                              "<div class = 'col-3 col-md-1'>"+
                                   "<img src='"+correctProfileImage+"' id='imgProfiloPost' class='rounded-circle'>"+
                               "</div>"+
                               "<div class = 'col-9 col-md-11'>"+
                                   "<p id='autorePost' class='card-text'> Post di "+listaPost[i].name+"</p>"+
                               "</div>"+
                               "</div>"+
                               "</div>"+
                               "</div><br>";
                               $("#divPost").append(cardPostI);
        }else{
            var lat=listaPost[i].lat;
            var lon = listaPost[i].lon
            let cardPostP =   "<div class='card' onClick='visualizzaMappa("+lat+","+lon+")' style='cursor:pointer;'>"+
                              "<div class='card-body'>"+
                                  "<p id='testoPost' class='card-text'>Posizione condivisa</p>"+
                                  "<hr>"+
                              "<div id='contenitoreDatiPost' class='row'>"+
                              "<div class = 'col-3 col-md-1'>"+
                                   "<img src='"+correctProfileImage+"' id='imgProfiloPost' class='rounded-circle'>"+
                               "</div>"+
                               "<div class = 'col-9 col-md-11'> "+
                                   "<p id='autorePost' class='card-text'> Post di "+listaPost[i].name+"</p>"+
                               "</div>"+
                               "</div>"+
                               "</div>"+
                               "</div><br>";
                               $("#divPost").append(cardPostP);

        }


    }
}
