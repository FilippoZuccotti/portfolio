class Channel {
  constructor(ctitle, mine){
    this.ctitle=ctitle;
    this.mine=mine;
  }
}

class Post{
    constructor(uid,name,pversion,pid,type,content,lat,lon,imgProfilo,imgPost){
        this.uid= uid;
        this.name= name;
        this.pversion= pversion;
        this.pid= pid;
        this.type= type;
        this.content= content;
        this.lat=lat;
        this.lon=lon;
        this.imgProfilo= imgProfilo;
        this.imgPost = imgPost;
    }

}
