package com.example.treest.Registrazione;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.Bacheca.Bacheca;
import com.example.treest.MainActivity;
import com.example.treest.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import com.theartofdev.edmodo.cropper.CropImage;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Registrazione#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Registrazione extends Fragment {
    private final static String TAG= MainActivity.class.getName();
    public static RequestQueue requestQueue;
    private EditText textNome;
    private ImageView imgProfilo;
    private String nome;
    private Bitmap bitmap;
    public static String imgBase64;
    private Uri resultUri;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Registrazione() {
        // Required empty public constructor
    }
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Registrazione.
     */
    // TODO: Rename and change types and number of parameters
    public static Registrazione newInstance(String param1, String param2) {
        Registrazione fragment = new Registrazione();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_registrazione, container, false);
        Button btnRegistrati=view.findViewById(R.id.btnRegistrati);
        Button btnCarica=view.findViewById(R.id.caricaImg);
        textNome=view.findViewById(R.id.textNome);
        imgProfilo =view.findViewById(R.id.imgProfilo);
        requestQueue = Volley.newRequestQueue(getContext());


        btnRegistrati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG,"PROVA:"+textNome);
                nome=textNome.getText().toString();
                if(nome.length()>20){ // controllo che il nome non sia troppo lungo
                    Context context = getContext();
                    CharSequence text = "il nome o l'immagine sono  troppo lunghi";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }else { // altrimenti chiamo la funzione register
                    Log.d(TAG, "CLICK SUL BOTTONE ORA TI REGISTRI");
                    register();
                }
            }
        });
        btnCarica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = CropImage.activity()
                        .setMultiTouchEnabled(true)
                        .setAspectRatio(1,1)
                        .getIntent(getContext());
                startActivityForResult(intent, CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE);//CHIAMA ONACTIVITY RESULT
            }
        });

        return view;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == getActivity().RESULT_OK) {
                resultUri = result.getUri();
                imgProfilo.setImageURI(resultUri);
                Log.e("resultUri ->", String.valueOf(resultUri));
                //fotoProfilo = 1;//foto profilo caricata
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), resultUri);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 15, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();
                    imgBase64=Base64.encodeToString(byteArray, Base64.DEFAULT);//SERVE PER LA CHIAMATA SETPROFILE
                    Log.d(TAG,imgBase64);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Log.e("error ->", String.valueOf(error));
            }
        }
    }

    public void register(){ //la funzione register serve per prendere il sid, che poi lo setto nelle sheredPref
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/register.php";
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String sid=response.getString("sid");
                            Log.d(TAG,"sid:"+sid);
                            SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = settings.edit();
                            editor.putString("SID", sid);
                            editor.commit();
                            setProfile(sid);  //una volta preso il sid, lo uso per fare la chiamata setProfile
                        }  catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, "Error while downloading SID: " + error.toString());
            }
        });
        requestQueue.add(request);
    }
    public void setProfile(String sid){  // serve per settare il nome e la foto di un profilo.
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/setProfile.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("name",nome);
            jsonBody.put("picture",imgBase64);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d(TAG,"json: "+jsonBody);
    JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
            url,
            jsonBody,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                   Log.d(TAG,"l'UTENTE è STATO REGISTRATO");
                    getProfile();
                    //quando l'utente è stato registrato viene fuori un alert che mi avvisa e poi vado alla bacheca.

                    DialogFragment dialogFragment=new FireMissilesDialogFragment();
                    dialogFragment.show(getFragmentManager(), "Conferma registrazione");
                    //salvo nome utente e immagine nelle shered
                    SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.putString("nome", nome);
                    editor.putString("img",imgBase64);
                    editor.commit();
                   //toBacheca();
                }
            }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.d("Volley", "Error: " + error.toString());
        }
    });
        requestQueue.add(request);
    }
    public void toBacheca(){
        //devo salvare il nome utente e l'eventauale immagine nelle SP
        SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("nome", nome);
        editor.putString("img",imgBase64);
        editor.commit();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        Bacheca fragmentBacheca=new Bacheca();
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentBacheca);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d(TAG, "Mi sposto al fragment bacheca");
    }

    public static class FireMissilesDialogFragment extends DialogFragment{
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("La registrazione è avvenuta correttamente")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                            Bacheca fragmentBacheca=new Bacheca();
                            fragmentTransaction.replace(R.id.fragmentContainer,fragmentBacheca);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                            Log.d(TAG, "Mi sposto al fragment bacheca");
                        }
                    });
            return builder.create();
        }
    }

    public void getProfile(){
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/getProfile.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                url,
                jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG,"Ricevo dati mi serve solo il mio udi e lo setto nell shered");
                        try {
                            String uid=response.getString("uid");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("UID", uid);
                            editor.commit();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //toBacheca();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Volley", "Error: " + error.toString());
            }
        });
        requestQueue.add(request);




    }



}