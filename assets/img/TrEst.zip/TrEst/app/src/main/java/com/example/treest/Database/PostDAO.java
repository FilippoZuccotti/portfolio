package com.example.treest.Database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PostDAO {

    //metodo per recuperare l'immagine di profilo di un post
    @Query("SELECT * FROM profiledatabase WHERE uid= :uid")
    List<ProfileDatabase> getProfileImage(int uid);

    //aggiungere un immagine profilo al db
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addProfileImage(ProfileDatabase image);

    //aggiornare un immagine profilo al db
    @Query("UPDATE profiledatabase SET img = :img, pversion= :pversion WHERE uid = :uid")
    void updateProfileImage(String img, int uid, int pversion);


}
