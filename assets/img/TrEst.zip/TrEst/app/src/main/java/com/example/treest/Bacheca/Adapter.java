package com.example.treest.Bacheca;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.treest.Interfaccia.OnListClickListener;
import com.example.treest.Model;
import com.example.treest.R;
import com.example.treest.Tratta.PostTratta;

public class Adapter extends RecyclerView.Adapter<ViewHolder> {
    private LayoutInflater mInflater;
    private OnListClickListener mListClickListener = null;
    private Bacheca listFragment;

    public Adapter (Context context,OnListClickListener listClickListener,Bacheca fragment){
        this.mInflater=LayoutInflater.from(context);
        mListClickListener = listClickListener;
        this.listFragment = fragment;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = mInflater.inflate(R.layout.single_tratta,parent,false);
       return new ViewHolder(view,mListClickListener,listFragment);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Tratta tratta = Model.getInstance().getTrattaByIndex(position);
        holder.setText(tratta); // richiamo il metodo per settare il testo.



       /* gestisco il click per ogni tratta  poi posso anche richiamare funzioni al suo interno.
        holder.btnTratta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = tratta.getPartenza();
                String direzione = tratta.getArrivo();

                Log.d("hai cliccato","hai clicato sulla tratta:"+nome+"con direzione:"+direzione);

            }
        });  */
    }

    @Override
    public int getItemCount() {
        return Model.getInstance().getTratteSize();
    }
}
