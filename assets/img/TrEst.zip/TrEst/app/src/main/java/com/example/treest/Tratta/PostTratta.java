package com.example.treest.Tratta;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.Aggiorna.Aggiorna;
import com.example.treest.Bacheca.Bacheca;
import com.example.treest.Database.ProfileDatabase;
import com.example.treest.Mappa.Map;
import com.example.treest.Model;
import com.example.treest.R;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationItemView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PostTratta#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PostTratta extends Fragment {

    public static RequestQueue requestQueue;
    private com.example.treest.Tratta.Adapter adapter;
    private int contProfilo;
    private String imgUtente;
    private int cont1;
    private MaterialToolbar topAppBar;
    public static Looper secondaryThread;
    private List<ProfileDatabase> profileImage;
    private int currentDID;
    private ProgressBar progressBar;

    private final static int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION=1;
    private boolean autorizzato=false;
    private LocationCallback locationCallback;
    private FusedLocationProviderClient fusedLocationProviderClient;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public PostTratta() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PostTratta.
     */
    // TODO: Rename and change types and number of parameters
    public static PostTratta newInstance(String param1, String param2) {
        PostTratta fragment = new PostTratta();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if(Model.getInstance().getPostsSize()>0){
            Model.getInstance().removePost();
        }
        adapter = null;
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        // prendo il did e il did opposto dalle sheredP
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        int did  = sharedPreferences.getInt("DID",-1);
        int opdid = sharedPreferences.getInt("OPDID",-1);

        //dichiarazione dell'handler per i thread
        HandlerThread handlerThread=new HandlerThread("myHandlerThread");
        handlerThread.start();
        secondaryThread=handlerThread.getLooper();

        requestQueue = Volley.newRequestQueue(getContext());


        setPost(did); // chiamo la funzione setPost.

        // questo serve per gestire il click indietro.
        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
            @Override
            public void handleOnBackPressed() {
                toFragmentBacheca();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view= inflater.inflate(R.layout.fragment_post_tratta, container, false);



        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        int did  = sharedPreferences.getInt("DID",-1);
        int opdid = sharedPreferences.getInt("OPDID",-1);

        // definisco la topAppBar in base al did anche l'intestazione cambia
        topAppBar=view.findViewById(R.id.topAppBar);
        String intestazione="";
        switch (did){
            case 1: intestazione="Celoria --> Rogoredo";
                break;
            case 2: intestazione="Rogoredo -->  Celoria";
                break;
            case 3: intestazione = "Sesto San Giovanni -->  Lambrate";
                break;
            case 4: intestazione = "Lambrate --> Sesto San Giovanni";
                break;
            default:intestazione="";
        }

        topAppBar.setTitle(intestazione);
        // se clicco sulla freccia della topAppBar torno alla bacheca
        topAppBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toFragmentBacheca();
            }
        });

        // definisco i bottoni della bottomBar

        BottomNavigationItemView btnCambioTratta=view.findViewById(R.id.cambio); // cambio tratta va alla tratta opposta
        btnCambioTratta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cambio(did,opdid); // vado alla pagina opposta
            }
        });
        BottomNavigationItemView btnAddPost = view.findViewById(R.id.aggiungi); // btn Add POST permette di commentare
        btnAddPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(); // apro il dialog per scrivere un commento
            }
        });
        BottomNavigationItemView btnMappa = view.findViewById(R.id.mappa);
        btnMappa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toMappa(); // vado alla mappa dove c'è la mia posizione e le stazioni di questa tratta
            }
        });

        BottomNavigationItemView btnProfilo = view.findViewById(R.id.profilo);
        btnProfilo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toAggiorna();   // vado alla pagina per aggiornare il profilo.
            }
        });
/*
        BottomNavigationItemView btnSponsor = view.findViewById(R.id.icona);
        btnSponsor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toNuovo();
            }
        });*/


        /* gestisco il click sul bottone nuovo della bottom bar
        BottomNavigationItemView btnNuovo = view.findViewById(R.id.icona);
        btnNuovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("prova","hai cliccato sul bottone nuovo");
            }
        });*/
        /* gestisco il click del bottone in alto a destra.
        ImageView bottone = view.findViewById(R.id.imageView2);
        bottone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Click bottone","ora andrai probabilente in un altro fragmnet");
            }
        });  */




        progressBar=view.findViewById(R.id.progressBar); // queste 2 righe servono per la barra di caricamento
        progressBar.setVisibility(View.VISIBLE);
        return view;
    }
    public void setPost(int did){ // serve per scaricare i post.

        scaricaPost(did, new VolleyCallBack() { // prima chiamo scaricaPost
            @Override
            public void onSuccess() throws Exception { // Quando ha finito chiama la getProfile
                getProfile(new VolleyCallBack() {
                    @Override
                    public void onSuccess() throws Exception {
                        Log.d("io sono qui","devo fare la recycler");
                        Log.d("lunghezza","la lunghezza del model è :"+Model.getInstance().getPostsSize());

                        RecyclerView recyclerView = getActivity().findViewById(R.id.recyclerViewPost);

                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(linearLayoutManager);
                        adapter = new com.example.treest.Tratta.Adapter(getContext(),PostTratta.this);
                        recyclerView.setAdapter(adapter);
                        recyclerView.getRecycledViewPool().clear();
                        adapter.notifyDataSetChanged();


                        progressBar.setVisibility(View.GONE);
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        });
    }

    public void scaricaPost(int did, VolleyCallBack callBack){
        contProfilo=0;
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");

        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/getPosts.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("did",did);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray posts=response.getJSONArray("posts"); // estraggo l'array di post

                            if(posts.length()==0) { // se non ci sono post nella bacheca, mi avvisa con un toast
                                Context context = getContext();
                                CharSequence text = "La bacheca è vuota";
                                int duration = Toast.LENGTH_SHORT;
                                Toast toast = Toast.makeText(context, text, duration);
                                toast.show();
                            }
                            for(int i=0; i<posts.length();i++){  // ora ciclo su ogni singolo post
                                JSONObject post=posts.getJSONObject(i);
                                int delay = 4; // come valore di default metto valore nulli a delay e status
                                int status = 3;
                                String comment= "nessuno commento"; // se non scrive nulla il valore di default è nesusn commento
                                if (post.has("delay")) { // se il post ha il delay allora prendo il valore
                                      delay = post.getInt("delay");
                                }
                                if (post.has("status")) { // stessa cosa per lo stato
                                      status = post.getInt("status");
                                }
                                if (post.has("comment")) { // stessa cosa per il commento
                                      comment = post.getString("comment");
                                }
                                // prendo tutti gli altri attributi del post.
                                Boolean follow = post.getBoolean("followingAuthor");
                                String data = post.getString("datetime");
                                String nomeUtente=post.getString("authorName");
                                String pv= post.getString("pversion");
                                String uid = post.getString("author");

                                if (Integer.parseInt(pv)!=0){
                                    contProfilo++;  // conto anche quante immagini profilo ci sono tra la lista di post, serve per ottimizzare.
                                }

                                Post p= new Post(uid,"14",nomeUtente,pv,null,delay,status,comment,follow,data); // una volta ricevuti tutti i dati creo l'oggetto post
                                Model.getInstance().addPost(p); // lo aggiungo al model.
                            }

                            callBack.onSuccess(); // quando ho finito di caricare tutto  faccio la onsuccess che mi fa passare alla chiamata successiva


                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("errore", "Error while downloading SID: " + error.toString());
            }
        });
        requestQueue.add(request);

    }

    public void getProfile(VolleyCallBack callBack) throws Exception { // la chiamata successiva è getProfile
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");

        Log.d("numero fp","il numero di foto è:"+contProfilo);
        List<Post> posts = Model.getInstance().getPost(); // scarico la lista dei post.

        int did=getArguments().getInt("did");
        Log.d("model","lungheza del model dentro la get profile: "+Model.getInstance().getPostsSize());
        Log.d("model","lungheza di list_post dentro la get profile: "+posts.size());
        cont1=0;
        if (contProfilo==0){
            // significa che non ci sono immagini profilo non le cerco nemmeno ottimizzo il tempo.
            callBack.onSuccess();
            return;
        }else{
            for (Post post : posts){ // ciclo sulla lista dei post scaricata e pe ogni post prendo lo UID e il Pversion.
                String uid = post.getUid();
                String pversion=post.getPversion();

                if (Integer.parseInt(pversion) !=0){ //se l apversion è diversa da 0 significa che c'è un immagine e controllo se è gia nel DB O MENO
                    // entro nel DB per farlo devo usare un thread secondario.
                    Handler handler = new Handler(secondaryThread);
                    handler.post(()->{
                        List<ProfileDatabase> profileImage;
                        //faccio una chiamata al db tramite metodo del model per prendere l'img utente con quel uid
                        profileImage = Model.getInstance(getContext()).getProfileImage(Integer.parseInt(uid));
                        // una volta presa l'immagine torna nel mio mainthread
                        Handler mainThread = new Handler(Looper.getMainLooper());
                        mainThread.post(()->{

                            //se la foto profilo è presente nel database allora controllo se è aggiornatta tramite pversion
                            if (profileImage.size()>0){
                                Log.d("PROVA","la foto è presente nel DB");
                                Log.d("prova","LA PVERSION NEL DB è :"+ profileImage.get(0).getPversion() +"MENTRE NEL MODEL è :"+pversion);
                                int pv = Integer.parseInt(pversion);
                                int pvDB = Integer.parseInt(profileImage.get(0).getPversion());
                                if(pv!= pvDB){//se la pv è diversa devo fare la chiamata di rete
                                    ////
                                    Log.d("prova","l'immagine profilo è una versione diversa a quella nel db quindi devo aggiornare la foto");
                                    updateProfilo(posts,post,callBack,sid, uid); // chiamo la funzione che mi scarica la foto nuova, modifica la PVERSION e la setta

                                }else{//se la versione è ugale devo aggiornare il model
                                    Log.d("prova","l'immagine profilo è uguale a quella nel db quindi devo solo aggiornare il model");

                                    post.setImg(profileImage.get(0).getImg()); // setto nel campo dell'img l'immagine dal db
                                    cont1++;
                                    if(cont1 == contProfilo){
                                        try {
                                            Model.getInstance().setPosts(posts);
                                            callBack.onSuccess();
                                            return;
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }else{
                                //se no è presente nel DB allora faccio la choiamata di rete e aggiungo la tupla al db e al model
                                Log.d("prova","l'immagine profilo non è nel db quindi devo fare una chiamata di rete");
                                newProfileImage(posts,post,callBack,sid, uid);
                            }
                        });
                    });
                }



            }
        }
    }

    public void newProfileImage(List<Post> posts,Post post, VolleyCallBack callBack, String sid, String uid){ // l'immagine è nuova
        // faccio una chiamata di rete per prendere la Foto
        final String url = "https://ewserver.di.unimi.it/mobicomp/treest/getUserPicture.php";
        final JSONObject jsonBody = new JSONObject();

        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String did = sharedPreferences.getString("SID","");
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("uid",uid);
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url,
                jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String risposta=response.toString();
                        try{
                            JSONObject jsonObject=new JSONObject(risposta);
                            String imgUtente = jsonObject.getString("picture"); // prendo si a immagine che pversion
                            String currentpv = jsonObject.getString("pversion");
                            imgUtente.replace("\n", "");

                            // prendo l'iimagine entro nel thread 2 per accedere al DB e poi aggiungo la tupla al DB.
                            Handler handler1 = new Handler(secondaryThread);
                            handler1.post(()->{
                                ProfileDatabase profileImage = new ProfileDatabase(imgUtente,currentpv,uid); // creo l'oggetto immagine
                                Model.getInstance(getContext()).addProfileImg(profileImage);// aggiungo la tupla dell immagine al DB tramite metodo nel model.
                                post.setImg(imgUtente); // setto nel post l'immagine
                                cont1++;
                                Handler mainHandler = new Handler(Looper.getMainLooper());
                                mainHandler.post(()->{
                                    if (cont1 == contProfilo){
                                        try {

                                            Model.getInstance().setPosts(posts); //ora setto tutto nel model per aggiornarlo
                                            callBack.onSuccess();
                                            return;
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }
                                });
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
        });

        requestQueue.add(request);

    }

    public void updateProfilo(List<Post> posts,Post post, VolleyCallBack callBack, String sid, String uid){
        // anche qui faccio una chiamata di rete ma devo solo aggiornare il database
        final String url = "https://ewserver.di.unimi.it/mobicomp/treest/getUserPicture.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("uid",uid);
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url,
                jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String risposta=response.toString();
                        try{
                            JSONObject jsonObject=new JSONObject(risposta);
                            String imgUtente = jsonObject.getString("picture");
                            String currentpv = jsonObject.getString("pversion");
                            imgUtente.replace("\n", "");
                            // prendo img e pv e poi le passo al DB

                            Handler handler1 = new Handler(secondaryThread);
                            handler1.post(()->{
                                Model.getInstance(getContext()).updateProfileImage(imgUtente,Integer.parseInt(uid),Integer.parseInt(currentpv)); // tramite metodo del model aggiorno nella tupla limmagine profilo e la pversion
                                post.setImg(imgUtente); // setto nel post l'immagine
                                cont1++;
                                Handler mainHandler = new Handler(Looper.getMainLooper());
                                mainHandler.post(()->{
                                    if (cont1 == contProfilo){
                                        try {

                                            Model.getInstance().setPosts(posts); // ora setto tutto nel model per aggiornarlo
                                            callBack.onSuccess();
                                            return;

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }
                                });
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(request);
    }


    public void toFragmentBacheca(){
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        Bacheca fragmentBacheca=new Bacheca();
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentBacheca);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d("prova", "Mi sposto al fragment bacheca");
    }
    public void openDialog(){ // quando clicco sul aggiungi comemtno mi si apre un altro dialog.
        CommentDialog commentDialog = new CommentDialog();
        commentDialog.show(getChildFragmentManager(),"Post");
    }
    public void refresh(int did){ // refresh serve per ricaricare la pagina corrente
        PostTratta postTratta = new PostTratta();
        Bundle args=new Bundle();
        args.putInt("did", did);
        postTratta.setArguments(args);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void cambio(int did, int opDid){ // viene chiamato quando clicco su cambia direzione.
        //devo invertire il did con l'opdid e poi aggiornare il fragment

        SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("DID", opDid);
        editor.putInt("OPDID",did);
        editor.commit();

        PostTratta postTratta = new PostTratta();
        Bundle args=new Bundle();
        args.putInt("did", did);
        postTratta.setArguments(args);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
    public void follow(String uid, String nome){ // questo mwtodo viene chiamato al click del icona difianco ad ogni post. Il click è gestito nel adapter

        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        int did = sharedPreferences.getInt("DID",-1);

        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("uid",uid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/follow.php";
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Context context = getContext();
                        CharSequence text = "Hai iniziato a seguire: "+nome;
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("errore", "Error while downloading SID: " + error.toString());
            }
        });

        requestQueue.add(request);
        refresh(did); // serve per ricaricare la pagina e prendere i dati dal server aggiornati con follow e unfollow


    }
    public void unFollow(String uid,String nome){  // è la stessa cosa del follow.
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        int did = sharedPreferences.getInt("DID",-1);

        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("uid",uid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/unfollow.php";
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Context context = getContext();
                        CharSequence text = "Hai smessp di seguire: "+nome;
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("errore", "Error while downloading SID: " + error.toString());
            }
        });
        requestQueue.add(request);

        refresh(did); // serve per ricaricare la pagina e prendere i dati dal server aggiornati con follow e unfollow
    }

    public void toAggiorna(){ // mi sposto al fragmnet per aggiornare i miei dati
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        Aggiorna fragmentAggiorna=new Aggiorna();
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentAggiorna);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d("prova", "Mi sposto al fragment aggiorna");
    }

    public void toMappa(){ // vado al fragment della mappa.
        int did=getArguments().getInt("did");
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        Map fragmentMappa=new Map();
        Bundle args=new Bundle();
        args.putInt("did", did);
        fragmentMappa.setArguments(args);
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentMappa);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d("prova", "Mi sposto al fragment mappa");
    }
/*
    public void toNuovo(){ // serve per spostarmi ad un eventuale nuovo fragment.
        fragment_Sponsor prova = new fragment_Sponsor();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,prova);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }*/



}

