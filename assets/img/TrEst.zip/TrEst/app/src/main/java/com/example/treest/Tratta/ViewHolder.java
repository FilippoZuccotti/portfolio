package com.example.treest.Tratta;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.treest.R;
import com.google.android.material.card.MaterialCardView;

public class ViewHolder extends RecyclerView.ViewHolder {

    //dichiaro tutto quello che c'è nel layout di singlePost
    public final TextView textContenuto;
    public final ImageView imgUtente;
    private PostTratta listFragment;
    public final TextView textNomeUtente;
    public final MaterialCardView cardPost;
    public final ImageView segui;
    public final ImageView nonsegui;

    //public final ImageView botton;  dichiarazione del bottone.

    // costruttore
    public ViewHolder(@NonNull View itemView,PostTratta fragment) {
        super(itemView);
        textContenuto = itemView.findViewById(R.id.textContenuto);
        imgUtente = itemView.findViewById(R.id.imgUtente);
        this.listFragment=fragment;
        textNomeUtente=itemView.findViewById(R.id.textUtente);
        cardPost=itemView.findViewById(R.id.cardPost);
        segui = itemView.findViewById(R.id.segui);
        nonsegui = itemView.findViewById(R.id.nonsegui);

        //botton = itemView.findViewById(R.id.bottoneProva); dichiarazione del bottone
    }



}
