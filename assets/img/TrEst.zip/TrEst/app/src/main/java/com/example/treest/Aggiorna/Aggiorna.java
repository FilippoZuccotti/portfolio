package com.example.treest.Aggiorna;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.R;
import com.example.treest.Tratta.PostTratta;
import com.google.android.material.appbar.MaterialToolbar;
import com.theartofdev.edmodo.cropper.CropImage;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Aggiorna#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Aggiorna extends Fragment {
    private EditText textNome;
    private ImageView imgProfilo;
    private Uri resultUri;
    private Bitmap bitmap;
    private String imgBase64;
    private String nomeVecchio;
    private String imgVecchia;
    public static RequestQueue requestQueue;
    private MaterialToolbar topAppBar;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Aggiorna() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Aggiorna.
     */
    // TODO: Rename and change types and number of parameters
    public static Aggiorna newInstance(String param1, String param2) {
        Aggiorna fragment = new Aggiorna();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        // prendo il did cosi può tornare indietro.
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        int did = sharedPreferences.getInt("DID",-1);

        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
            @Override
            public void handleOnBackPressed() {
                toTratta(did+1);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
        //recupero il mio nome e la mia immagine dalle shered.
        nomeVecchio = sharedPreferences.getString("nome","");
        Log.d("il tuo  nome è","il tuo nome è"+nomeVecchio);
        imgVecchia = sharedPreferences.getString("img","");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_aggiorna, container, false);

        textNome=view.findViewById(R.id.textAggiorna);
        imgProfilo =view.findViewById(R.id.imgProfiloA);
        topAppBar=view.findViewById(R.id.topAppBar);
        topAppBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
                int did = sharedPreferences.getInt("DID",-1);
                toTratta(did);
            }
        });
        imgBase64=imgVecchia;
        requestQueue = Volley.newRequestQueue(getContext());
        // se il nome vecchio esisteva allora lo setto nella textNome.
        if(nomeVecchio.length()>1) {
            textNome.setText(nomeVecchio);
        }

        // stessa cosa per l'immagine se esiste la setto nella Img View.
        if (imgVecchia.length()>1) {
            byte[] code = Base64.decode(imgVecchia, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(code, 0, code.length);
            //decodifca
            imgProfilo.setImageBitmap(bitmap);
        }

        Button bntImg = view.findViewById(R.id.caricaImgA);
        bntImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = CropImage.activity()
                        .setMultiTouchEnabled(true)
                        .setAspectRatio(1,1)
                        .getIntent(getContext());
                startActivityForResult(intent, CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE);//CHIAMA ONACTIVITY RESULT
            }
        });

        Button btnAggiorna = view.findViewById(R.id.btnAggiorna);

        btnAggiorna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textNome.getText().toString().length()>20){
                    Context context = getContext();
                    CharSequence text = "Nome troppo lungo non va bene!";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }else{
                    if(nomeVecchio.length()>0 && textNome.getText().toString().length()<1){
                        Context context = getContext();
                        CharSequence text = "Non puoi cancellare il nome se ne hai gia uno!";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }else {
                        aggiornaDati(textNome.getText().toString(), imgBase64); // chiamo la funzione per aggiornare i dati.
                    }
                }
            }
        });

        return view;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == getActivity().RESULT_OK) {
                resultUri = result.getUri();
                imgProfilo.setImageURI(resultUri);

                //fotoProfilo = 1;//foto profilo caricata
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), resultUri);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 15, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();
                    imgBase64=Base64.encodeToString(byteArray, Base64.DEFAULT);//SERVE PER LA CHIAMATA SETPROFILE

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Log.e("error ->", String.valueOf(error));
            }
        }
    }

    public void aggiornaDati(String nomeA, String imgA){
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
            //aggiorno i dati pero prima controllo che i dati siano stati cambiati
            Log.d("nomi","nome vecchio"+nomeVecchio+"nomeNuovo"+nomeA);

            if (nomeA.equals(nomeVecchio) && imgA.equals(imgVecchia)){ //controllo che almeno un parametro sia cambiato
                Context context = getContext();
                CharSequence text = "Devi cambiare alemeno un elemento per aggiornare il profilo";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }else if (!nomeA.equals(nomeVecchio) && imgA.equals(imgVecchia)){ // se ho cambiato solo il nome
                //solo i dati del nome sono stati aggiornati
                final JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("sid",sid);
                    jsonBody.put("name",nomeA);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //chiamo la setProfile per inviare le modifiche al server e setto nelle shered pref le nuove modifiche
                setProfile(jsonBody);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("nome", nomeA);

                editor.commit();
            }else if (nomeA.equals(nomeVecchio) && !imgA.equals(imgVecchia)){ // se ho cambiato solo l'immagine
                //solo i dati del immagini sono aggiornati
                final JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("sid",sid);
                    jsonBody.put("picture",imgA);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //chiamo la setProfile per inviare le modifiche al server e setto nelle shered pref le nuove modifiche
                setProfile(jsonBody);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("img", imgA);
                editor.commit();

            }else{ // se ho cambiato tutti i dati
                //tutti i dati sono stati aggiornati
                final JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("sid",sid);
                    jsonBody.put("picture",imgA);
                    jsonBody.put("name",nomeA);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //chiamo la setProfile per inviare le modifiche al server e setto nelle shered pref le nuove modifiche
                setProfile(jsonBody);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("nome", nomeA);
                editor.putString("img", imgA);
                editor.commit();


            }

    }

    public void setProfile(JSONObject jsonBody){
        // gli ho passat il jsoBody devo mandarlo al server per aggiornare i miei dati, una volta finito torno indietro alla mia tratta.
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        int did = sharedPreferences.getInt("DID",-1);
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/setProfile.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                url,
                jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("AGGIORNA","l'UTENTE è STATO AGGIORNATO");
                        Context context = getContext();
                        CharSequence text = "profilo aggiornato!";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        toTratta(did+1);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Volley", "Error: " + error.toString());
            }
        });
        requestQueue.add(request);
    }
    public void toTratta(int did){
        PostTratta postTratta = new PostTratta();
        Bundle args=new Bundle();
        args.putInt("did", did);
        postTratta.setArguments(args);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

}