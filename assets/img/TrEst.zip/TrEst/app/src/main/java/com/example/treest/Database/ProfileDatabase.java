package com.example.treest.Database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class ProfileDatabase {


    @ColumnInfo(name="img")
    private String img;

    @ColumnInfo(name="pversion")
    private String pversion;

    @PrimaryKey
    @NonNull
    private String uid;

    public ProfileDatabase(String img, String pversion, @NonNull String uid) {
        this.img = img;
        this.pversion = pversion;
        this.uid = uid;
    }



    public String getImg() { return img; }

    public void setImg(String img) { this.img = img; }

    public String getPversion() { return pversion; }

    public void setPversion(String pversion) { this.pversion = pversion; }

    @NonNull
    public String getUid() { return uid; }

    public void setUid(@NonNull String uid) { this.uid = uid; }
}
