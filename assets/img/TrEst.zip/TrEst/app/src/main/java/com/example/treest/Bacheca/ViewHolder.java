package com.example.treest.Bacheca;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.treest.Interfaccia.OnListClickListener;
import com.example.treest.R;
import com.google.android.material.card.MaterialCardView;

public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    // dichiaro tutti gli elementi grafici che ci sono nel layout della singola tratta
    public MaterialCardView cardView;
    private OnListClickListener mListClickListener = null;
    private TextView textTratta;
    private Bacheca listFragment;
    private TextView textDirezione;

   // public final ImageView btnTratta; dichiaro il bottone nuovo
    //costruttore
    public ViewHolder(@NonNull View itemView, OnListClickListener listClickListener,Bacheca fragment) {
        super(itemView);
        textTratta = itemView.findViewById(R.id.textTratta);
        textDirezione = itemView.findViewById(R.id.textDirezioneTratta);
        cardView = itemView.findViewById(R.id.card);
        itemView.setOnClickListener(this);
        mListClickListener = listClickListener;
        this.listFragment = fragment;

        //btnTratta = itemView.findViewById(R.id.btnTratta);    dichairo il bottone nuovo
    }

    public void setText(Tratta tratta){ // questo metodo mi setta il testo all'interno della recyclerView è un metodo richiamato dall'Adpeter
        textTratta.setText(tratta.getPartenza());
        textDirezione.setText(tratta.getArrivo());
    }

    @Override
    public void onClick(View view) { //Gestione del metodo OnClick.
        mListClickListener.onListClick(getAdapterPosition());
        listFragment.onClickViewHolder(view, getAdapterPosition());
    }
}
