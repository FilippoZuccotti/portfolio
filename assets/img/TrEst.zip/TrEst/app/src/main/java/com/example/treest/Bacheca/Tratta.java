package com.example.treest.Bacheca;

public class Tratta {
    private String partenza;
    private String arrivo;
    private int id; //id sarebbe il did
    private int opDid;

    public Tratta(String partenza, String arrivo, int id, int opDid) {
        this.partenza = partenza;
        this.arrivo = arrivo;
        this.id = id;
        this.opDid = opDid;
    }

    public String getPartenza() {
        return partenza;
    }

    public void setPartenza(String partenza) {
        this.partenza = partenza;
    }

    public String getArrivo() {
        return arrivo;
    }

    public void setArrivo(String arrivo) {
        this.arrivo = arrivo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOpDid() {
        return opDid;
    }

    public void setOpDid(int opDid) {
        this.opDid = opDid;
    }
}
