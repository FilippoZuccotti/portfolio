package com.example.treest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import com.example.treest.Bacheca.Bacheca;
import com.example.treest.Mappa.Map;
import com.example.treest.Registrazione.Registrazione;
import com.example.treest.Tratta.PostTratta;

import static java.security.AccessController.getContext;

public class MainActivity extends AppCompatActivity {
    private final static String TAG=MainActivity.class.getName();
    private final static int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION=1;
    public static boolean autorizzato=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        int did = sharedPreferences.getInt("DID",-1);
        if(checkSid(this)){  // se torna true significa che il sid non c'è e devo andare al fragment registrazione
            Log.d(TAG,"IL SID NON è ANCORA REGISTRATO");
            toRegistrazione();
        }else if (did!=-1){ //altrimenti significa che l'utente è gia registrato, preò controllo anche il did, può dari che un utente non selezioni nessuna tratta preferita.
            Log.d(TAG,"IL SID è GIA REGISTRATO e L'utente ha una tratta preferito"); // se la scelgie
            toTratta(did); // lo manda alla tratta
        }else{ // altrimenti lo mando alla bacheca dove sceglierà il preferito
            toBacheca();
        }

    }


    public boolean checkSid(Activity activity){ // contorllo se l'utente è registrato
        SharedPreferences sharedPreferences = activity.getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        if(sid.matches("")){
            return true; // non è registrato
        }else{
            return false; // è registrato
        }
    }
    public void toRegistrazione(){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Registrazione fragmentRegistrazione=new Registrazione();
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentRegistrazione);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d(TAG, "Mi sposto al fragment registrazione");
    }

    public void toBacheca(){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Bacheca fragmentBacheca=new Bacheca();
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentBacheca);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d(TAG, "Mi sposto al fragment bacheca");
    }

    public void toTratta(int did){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        PostTratta postTratta = new PostTratta();
        Bundle args=new Bundle();
        args.putInt("did", did+1);
        postTratta.setArguments(args);
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult( requestCode, permissions,grantResults);
        Log.d("OnRequest", "sono entrato nel metodo onRequestPermissions");

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted
                    Log.d("LocationMaps", "Ora sono stati concessi i permessi");
                    autorizzato=true;
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    Map fragmentMappa=new Map();
                    Bundle args=new Bundle();
                    fragmentMappa.setArguments(args);
                    fragmentTransaction.replace(R.id.fragmentContainer,fragmentMappa);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                    Log.d("LocationsMaps", "refresho il fragment map");

                } else {
                    Log.d("Location", "Non sono ancora stati concessi i permessi");
                }
                return;
            }
        }
    }

}