package com.example.treest.Test;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.treest.R;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link form#newInstance} factory method to
 * create an instance of this fragment.
 */
public class form extends Fragment {

    private MaterialToolbar topAppBar;
    TextView Tnome;
    TextView Tcognome;
    TextView Tcitta;
    TextView Tmail;
    TextView Tcodice;
    TextView Tpassword;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public form() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment form.
     */
    // TODO: Rename and change types and number of parameters
    public static form newInstance(String param1, String param2) {
        form fragment = new form();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_form,container,false);

        topAppBar=view.findViewById(R.id.topAppBar);
        topAppBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //gestisco l'onclick indietro
            }
        });

        Tnome = view.findViewById(R.id.nome_form);
        Tcognome = view.findViewById(R.id.cognome_form);
        Tcitta = view.findViewById(R.id.città_form);
        Tmail = view.findViewById(R.id.mail_form);
        Tcodice = view.findViewById(R.id.codice_form);
        Tpassword = view.findViewById(R.id.password_form);
        Button bottone = view.findViewById(R.id.button_form);
        prendiDati();

        bottone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("click","click sul bottone");
                settaDati();
            }
        });
        return view;

    }

    public void prendiDati(){
        SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
        String nome = settings.getString("nome","");
        String cognome = settings.getString("cognome","");
        String citta = settings.getString("citta","");
        String mail = settings.getString("mail","");
        String codice = settings.getString("codice","");
        String password = settings.getString("password","");

        Tnome.setText(nome);
        Tcognome.setText(cognome);
        Tcitta.setText(citta);
        Tmail.setText(mail);
        Tcodice.setText(codice);
        Tpassword.setText(password);
        Log.d("dati","dati caricati");
    }


    public void settaDati() {

        String nome = Tnome.getText().toString();
        String cognome = Tcognome.getText().toString();
        String citta = Tcitta.getText().toString();
        String mail = Tmail.getText().toString();
        String codice = Tcodice.getText().toString();
        String password = Tpassword.getText().toString();

        if (nome.length() < 1 || cognome.length() < 1 || citta.length() < 1 || mail.length() < 1 || codice.length() < 1 || password.length() < 1) {
            Log.d("no", "i dati devono essere tutti presenti non vale cosi");
        } else {
            final JSONObject jb = new JSONObject();
            try {
                jb.put("citta", citta);
                jb.put("mail", mail);
                jb.put("codice", codice);
                jb.put("password", password);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            final JSONObject jsonBody = new JSONObject();
            try {
                jsonBody.put("nome", nome);
                jsonBody.put("cognome", cognome);
                jsonBody.put("info", jb);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            Log.d("il tuo jsbody", "json: " + jsonBody);

            SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("nome", nome);  // aggiungo alle shered sia il did che l'opposit did
            editor.putString("cognome", cognome);
            editor.putString("citta", citta);
            editor.putString("mail", mail);
            editor.putString("codice", codice);
            editor.putString("password", password);
            editor.commit();

            Log.d("dati", "dati settati");
        }
    }
}