package com.example.treest.Tratta;

public interface VolleyCallBack {
    void onSuccess() throws Exception;
}
