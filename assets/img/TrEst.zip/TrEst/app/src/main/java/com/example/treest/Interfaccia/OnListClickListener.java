package com.example.treest.Interfaccia;

public interface OnListClickListener {
    public void onListClick(int position);
}
