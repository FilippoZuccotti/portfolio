package com.example.treest.Mappa;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.Interfaccia.OnListClickListener;
import com.example.treest.MainActivity;
import com.example.treest.R;
import com.example.treest.Tratta.PostTratta;
import com.example.treest.Tratta.VolleyCallBack;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Map#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Map extends Fragment  {
    //fragment della mappa visualizzo la mia posizione e quella delle stazioni vicine.
    private final static int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION=1;
    private MaterialToolbar topAppBar;
    private LocationCallback locationCallback;
    private FusedLocationProviderClient fusedLocationProviderClient;
    public static RequestQueue requestQueue;
    List<JSONObject> stations = new ArrayList<JSONObject>();
    private int indiceVicino=0;


    /*Collegare le stazioni con una linea
    Polyline polyline = null;
    List <LatLng> latLngList = new ArrayList<>();
    List <Marker> markerList = new ArrayList<>();*/

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Map() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Map.
     */
    // TODO: Rename and change types and number of parameters
    public static Map newInstance(String param1, String param2) {
        Map fragment = new Map();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        int did=getArguments().getInt("did");
        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
            @Override
            public void handleOnBackPressed() {
                toTratta(did);
            }
        };


        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
        requestQueue = Volley.newRequestQueue(getContext());

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this.getActivity());

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult){
               Log.d("Result","ora vado qua");
                if (locationResult == null){
                    return;}

                Location posizione=locationResult.getLastLocation();
                Log.d("Location", "New Location received: " + posizione.toString());
                Log.d("posizione","Lat"+posizione.getLatitude()+"Lon:"+posizione.getLongitude());

                Double lat=posizione.getLatitude();
                Double lon=posizione.getLongitude();

                SupportMapFragment smf = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapS);
                smf.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(@NonNull GoogleMap googleMap) {
                        // quando apro la mappa faccio get Station che prende le stazioni di quella tratta e le mette in una lista di stazioni chiamate stations.
                        googleMap.setMapType(googleMap.MAP_TYPE_NORMAL);
                        getStation(new VolleyCallBack() {
                            @Override
                            public void onSuccess() throws Exception {
                                // una volta finita la getStation prendo l'array do stazioni ne estraggo le coordinate e il nome e le posziono con un icona del treno sulla mappa.
                                for(int i=0;i<stations.size();i++){
                                    try{
                                        Log.d("nome","nome stazioni"+ stations.get(i).getString("nome"));
                                        String nome = stations.get(i).getString("nome");
                                        String lat = stations.get(i).getString("lat");
                                        String lon = stations.get(i).getString("lon");
                                        MarkerOptions stz = new MarkerOptions();
                                        LatLng coordinate = new LatLng(Double.parseDouble(lat),Double.parseDouble(lon));
                                        stz.position(coordinate);
                                        stz.title(nome);
                                        stz.icon(bitmapDescriptorFromVector(getContext(),R.drawable.ic_baseline_train_24));
                                        googleMap.addMarker(stz).showInfoWindow();
                                        /*collegare le stazioni con una linea
                                        latLngList.add(coordinate);
                                        markerList.add(googleMap.addMarker(stz));*/

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                                //quando ho finito con le stazioni creo un marker dove indica la mia posizione.
                                MarkerOptions io = new MarkerOptions();
                                LatLng coordinate = new LatLng(lat,lon);
                                io.title("tu sei qui");
                                io.position(coordinate);
                                io.icon(bitmapDescriptorFromVector(getContext(),R.drawable.ic_baseline_location_on_24));
                                googleMap.addMarker(io).showInfoWindow();
                                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(coordinate,12)); // faccio vedere dov'è l'utente tanto lo metterò vicino alle stazioni.
                                vicina(stations,coordinate);

                                /* gestisco nel caso in cui faccio click sul marker
                                googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                                                                  @Override
                                                                  public boolean onMarkerClick(Marker m) {
                                                                      Log.d("click","click sul marker"+m.getTitle());
                                                                      return true;
                                                                  }
                                                              });
                                 */


                                /* collegare le stazioni con una linea
                                PolylineOptions polylineOptions = new PolylineOptions()
                                        .addAll(latLngList);
                                polyline = googleMap.addPolyline(polylineOptions);*/


                            }
                        });
                    }
                });
            }
        };
        generatePosition();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_map, container, false);

        topAppBar=view.findViewById(R.id.topAppBar);
        topAppBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int did=getArguments().getInt("did");
                toTratta(did);
            }
        });


        return view;
    }

    public void generatePosition(){
        Log.d("poition","sono nel generate position");
        if(checkPermissions()){
            startLocationUpdates();
        }
    }
    public boolean checkPermissions(){
        //controllo che l'utente abbia concesso le autorizzazioni
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //se non le ha ancora concesse, gliele chiedo
            ActivityCompat.requestPermissions(this.getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        } else{
            MainActivity.autorizzato = true;
        }
        return MainActivity.autorizzato;
    }

    @SuppressLint("MissingPermission")
    private void startLocationUpdates(){
        Log.d("update","sono nel locationUpdate");
        com.google.android.gms.location.LocationRequest locationRequest = com.google.android.gms.location.LocationRequest.create();

        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        fusedLocationProviderClient.requestLocationUpdates(locationRequest,locationCallback, Looper.getMainLooper());
    }


    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) { // serve per camivare le icone
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }


    public void getStation(VolleyCallBack volleyCallBack){ // chiamate per prendere le stazioni di quella tratta.
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        int did = sharedPreferences.getInt("DID",-1);


        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/getStations.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("did",did);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("hey","io sono nel getSTtion");
                        try {
                            JSONArray stazioni=response.getJSONArray("stations");
                            for(int i=0;i<stazioni.length();i++){
                                JSONObject stazione = stazioni.getJSONObject(i);
                                String nome = stazione.getString("sname");
                                String lat = stazione.getString("lat");
                                String lon = stazione.getString("lon");
                                JSONObject js = new JSONObject();
                                js.put("nome",nome);
                                js.put("lat",lat);
                                js.put("lon",lon);
                                stations.add(i,js);
                            }
                            volleyCallBack.onSuccess();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("errore", "Error while downloading SID: " + error.toString());
            }
        });
        requestQueue.add(request);
    }

    public void toTratta(int did){ // torno indietro alla mia tratta.
        PostTratta postTratta = new PostTratta();
        Bundle args=new Bundle();
        args.putInt("did", did);
        postTratta.setArguments(args);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void vicina(List<JSONObject> stazioni,LatLng coordinate) throws JSONException {
        //CERCO LA STAZIONE PIU VICINA TRA QUELLE DELLA TRATTA
        JSONObject stazione = null;
        double distance = 0;
        for(int i=0;i<stazioni.size();i++){
            Double lat = Double.parseDouble(stazioni.get(i).getString("lat"));
            Double lon= Double.parseDouble(stazioni.get(i).getString("lon"));
            LatLng coordinate2 = new LatLng(lat,lon);

            Double currentDistance = getDistanceInMeter(coordinate,coordinate2);
            if(i == 0 ) { // Initially we are assuming first position is the nearest
                distance = currentDistance;
                indiceVicino = i;
            } else {
                if(currentDistance < distance) {
                    distance = currentDistance;
                    indiceVicino = i;
                }
            }
        }
        Context context = getContext();
        CharSequence text = "La stazione più vicina a te è la stazione di"+stazioni.get(indiceVicino).getString("nome");
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    private double getDistanceInMeter(LatLng start, LatLng end) {
        Location startPoint=new Location("locationA");
        startPoint.setLatitude(start.latitude);
        startPoint.setLongitude(start.longitude);
        Location endPoint=new Location("locationB");
        endPoint.setLatitude(end.latitude);
        endPoint.setLongitude(end.longitude);
        double distance=startPoint.distanceTo(endPoint);
        return distance;
    }

    public void refreshMap(){
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        Map fragmentMappa=new Map();
        Bundle args=new Bundle();
        fragmentMappa.setArguments(args);
        fragmentTransaction.replace(R.id.fragmentContainer,fragmentMappa);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        Log.d("LocationsMaps", "refresho il fragment map");
    }



}
