package com.example.treest.Tratta;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.Bacheca.Bacheca;
import com.example.treest.Model;
import com.example.treest.R;
import com.theartofdev.edmodo.cropper.CropImage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class CommentDialog extends AppCompatDialogFragment {
    String selectedR=null;
    String selectedS = null;
    private EditText EDcommento;
    private RadioGroup RGorario;
    private RadioGroup RGStato;
    private RadioButton radioOrario;
    private RadioButton radioStato;
    public static RequestQueue requestQueue;

    int sceltaO;
    int sceltaS;
    String commento ="";
    /* se dovessi mettere un immagine nel post, potrei fare cosi oppure creare un nuovo dialog, forse meglio.
    private Uri resultUri;
    private Bitmap bitmap;
    private ImageView imgProfilo;
    private String imgBase64;
    private Button immagine;
    */
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        String [] ritardo = {"un po di ritardo","molto in ritardo","cancellato"}; // questo serve eper
        String [] stato ={"perfetto","decete","pessimo"};

        // definisco la view e tutti gli elementi grafici
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog,null);
        requestQueue = Volley.newRequestQueue(getContext());
        EDcommento = view.findViewById(R.id.edit_commento);
        RGorario = view.findViewById(R.id.radioGroup1);
        RGStato = view.findViewById(R.id.radioGroup2);
        //imgProfilo =view.findViewById(R.id.vediImmagine);

        /*gestisco il click nel bottone in questo caso mi fa scelgiere l'immagine
        immagine = view.findViewById(R.id.postImmagine);
        immagine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("aggiungi","clicca su aggiungi immagine");
                Intent intent = CropImage.activity()
                        .setMultiTouchEnabled(true)
                        .setAspectRatio(1,1)
                        .getIntent(getContext());
                startActivityForResult(intent, CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE);//CHIAMA ONACTIVITY RESULT
            }
        });*/

        builder.setView(view)
                .setTitle("Aggiungi Post")
                .setNegativeButton("cancella", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Invia", new DialogInterface.OnClickListener() { // se schiaccio su Invia
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        commento = EDcommento.getText().toString();   // prendo il commento

                          int radioID = RGorario.getCheckedRadioButtonId();
                          int radioID2 = RGStato.getCheckedRadioButtonId();
                          Log.d("prova",""+radioID2);
                          if(radioID != -1) {
                              radioOrario = view.findViewById(radioID); // il valore dell'orario
                              switch(radioOrario.getText().toString()){
                                  case "In orario":
                                      sceltaO = 0;
                                      break;
                                  case "Leggero ritardo":
                                      sceltaO = 1;
                                      break;
                                  case "Ritardo di 15 minuti o più":
                                      sceltaO = 2;
                                      break;
                                  case "Treno soppresso":
                                      sceltaO = 3;
                                      break;
                                  default:
                                      sceltaO =-1;
                              }

                          }else{
                              sceltaO = -1;
                          }
                          if (radioID2!=-1){
                              radioStato = view.findViewById(radioID2); // il valore dello stato
                              switch(radioStato.getText().toString()){
                                  case "Condizioni ottimali":
                                      sceltaS = 0;
                                      break;
                                  case "Condizioni discrete":
                                      sceltaS = 1;
                                      break;
                                  case "Passeggieri in pericolo":
                                      sceltaS = 2;
                                      break;
                                  default:
                                      sceltaS =-1;
                              }
                          }else{
                              sceltaS = -1;
                          }

                        if(commento.length()<1 && sceltaO ==-1 && sceltaS ==-1){ // se sia commento che stato che ritardo non ci sono non si puo creare il post.
                            Context context = getContext();
                            CharSequence text = "IL post è vuoto non può essere creato";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        }else{ // se invece almeno uno ei 3 c'è controllo prima se il commento non sia troppo lungo e nel caso vada bene faccio la chiamata alla funzione addPost.
                            Log.d("ok","il tuo commetnto è :"+commento+"e il bottone orario premuto è"+sceltaO+"l'altro invece è "+sceltaS);
                            try {
                                if(commento.length()>100) {
                                    Context context = getContext();
                                    CharSequence text = "Errore! lunghezza massima consentita 100 caratteri!";
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                }else{
                                    addPost(commento, sceltaO, sceltaS);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        // una volta aggiunto il post, refresh il canale in modo di avere i  post aggiornati.
                        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
                        int did = sharedPreferences.getInt("DID",-1);
                        ((PostTratta) getParentFragment()).refresh(did);
                    }
                });

        return builder.create();
    }
    public void addPost(String commento,int sceltaO,int sceltaS) throws JSONException {
        // è una chiamata di rete che server per aggiungere un post.

        //devo prendere il did per aggiungere il post alla tratta giusta.
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/addPost.php";
        Log.d("addPost","sono nella funzione add post");
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        int did = sharedPreferences.getInt("DID",-1);
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
            jsonBody.put("did",did);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ora devo fare una serie di controllo per capire cosa aggiungere al mio json da mandare
        if(commento.length()<1 && sceltaO ==-1){//c'è solo sceltaS
            jsonBody.put("status",sceltaS);
        }else if (commento.length()<1 && sceltaS ==-1){ //c'è solo sceltaO
            jsonBody.put("delay",sceltaO);
        }else if (commento.length()<1 && sceltaO >=0 && sceltaS >=0){ //manca solo il commento
            jsonBody.put("delay",sceltaO);
            jsonBody.put("status",sceltaS);
        }else if (commento.length()>0 && sceltaO==-1 && sceltaS ==-1){ //c'è solo il commento
            jsonBody.put("comment",commento);
        }else if (commento.length()>0 && sceltaO>=0 && sceltaS ==-1){ // manca solo lo stato
            jsonBody.put("comment",commento);
            jsonBody.put("delay",sceltaO);
        }else if (commento.length()>0 && sceltaO==-1 && sceltaS >=0){//manca solo l'orario
            jsonBody.put("comment",commento);
            jsonBody.put("status",sceltaS);
        }else{//ci sono tutte e 3
            jsonBody.put("comment",commento);
            jsonBody.put("delay",sceltaO);
            jsonBody.put("status",sceltaS);
        }

        Log.d("TEST JSON","IL JSON è: "+ jsonBody);
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) { // quando arriva la risposta mi viene fuori un toast.
                        Log.d("post creato","post creato");
                        Context context = getContext();
                        CharSequence text = "Post creato con successo";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("errore", "Error while downloading SID: " + error.toString());
            }
        });

        requestQueue.add(request);
    }


    /* cose per settare la foto
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == getActivity().RESULT_OK) {
                resultUri = result.getUri();
                imgProfilo.setImageURI(resultUri);

                //fotoProfilo = 1;//foto profilo caricata
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), resultUri);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 15, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();
                    imgBase64= Base64.encodeToString(byteArray, Base64.DEFAULT);//SERVE PER LA CHIAMATA SETPROFILE

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Log.e("error ->", String.valueOf(error));
            }
        }
    }*/

}
