package com.example.treest.Bacheca;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.treest.Interfaccia.OnListClickListener;
import com.example.treest.MainActivity;
import com.example.treest.Model;
import com.example.treest.R;

import com.example.treest.Tratta.PostTratta;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Bacheca#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Bacheca extends Fragment implements OnListClickListener { // è una recyclerView con CLick listener
    private final static String TAG= MainActivity.class.getName();
    public static RequestQueue requestQueue;
    private Adapter adapter;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Bacheca() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Bacheca.
     */
    // TODO: Rename and change types and number of parameters
    public static Bacheca newInstance(String param1, String param2) {
        Bacheca fragment = new Bacheca();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_bacheca, container, false);
        Model.getInstance().removeTratte();
        requestQueue = Volley.newRequestQueue(getContext());
        getLines();// la prima funzione che faccio è per scaricare le  tratte


        /* qui gestisco il click dei 2 bottoni all'interno della bacheca
        Button bottone2 = view.findViewById(R.id.btnBacheca2);
        bottone2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("click bacheca","Hai cliccato sul bottone della bacheca2");
                toTest();
            }
        });

        Button bottone = view.findViewById(R.id.btnBacheca1);
        bottone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("click bacheca","Hai cliccato sul bottone della bacheca1");
            }
        });*/




        return view;
    }
    public void getLines(){
        SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SID","");
        final String url= "https://ewserver.di.unimi.it/mobicomp/treest/getLines.php";
        final JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("sid",sid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest( Request.Method.POST, url,jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray linee=response.getJSONArray("lines");
                            for(int i=0;i<linee.length();i++){
                                JSONObject tratta = linee.getJSONObject(i); // prendo la linea
                                Log.d(TAG,"la tratta è: "+tratta);
                                String partenza=tratta.getJSONObject("terminus1").getString("sname");// estraggo la tratta t1
                                String arrivo = tratta.getJSONObject("terminus2").getString("sname"); // estraggo la tratta t2
                                int did = tratta.getJSONObject("terminus1").getInt("did"); // estraggo il did della tratta t1
                                int did2 = tratta.getJSONObject("terminus2").getInt("did"); // estraggpo il did della tratta t2
                                String nomeT = partenza+"-"+arrivo;  // do un nome alla tratta
                                Tratta ObjTratta = new Tratta(nomeT,"Direzione "+arrivo,did,did2); // creo l'oggetto tratta fatto da nome, la direzione, il suo did e il did opposto(serve per switchare velocemente tra 2 tratte complementari)
                                Model.getInstance().addTratta(ObjTratta); // aggiungo la tratta al model
                                Tratta ObjTratta2 = new Tratta(nomeT,"Direzione "+partenza,did2,did); // faccio la stessa cosa con la tratta di "ritorno"
                                Model.getInstance().addTratta(ObjTratta2); // aggiungo la tratta al model
                            }
                            // una volta che ho finito di aggiungere tutte le tratte, le faccio vedere nella recyclerView. Gestita dall'adapter e dal ViewHolder.
                            RecyclerView recyclerView = getActivity().findViewById(R.id.recyclerViewLinee);
                            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                            recyclerView.setLayoutManager(linearLayoutManager);
                            adapter = new Adapter(getContext(),Bacheca.this::onListClick,Bacheca.this);
                            recyclerView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, "Error while downloading SID: " + error.toString());
            }
        });
        requestQueue.add(request);
    }


    @Override
    public void onListClick(int position) {
        Log.d("RecyclerViewExample", "From Main Activity: " + position);

    }
    public void onClickViewHolder(View view, int position){
        int did= position+1;
        int opdid = Model.getInstance().getTrattaByDID(did).getOpDid();
        Context context = getContext();
        CharSequence text = "La tratta è stata aggiunta ai preferiti";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        //ho messo nelle shered preferences la tratta preferita dell'utente.
        SharedPreferences settings = getActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("DID", did);  // aggiungo alle shered sia il did che l'opposit did
        editor.putInt("OPDID",opdid);
        editor.commit();

        PostTratta postTratta = new PostTratta();
        Log.d("tag di prova","il hai cliccato su:"+ Model.getInstance().getTrattaByIndex(position).getId());
        Bundle args=new Bundle();
        args.putInt("did", Model.getInstance().getTrattaByIndex(position).getId());
        postTratta.setArguments(args);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,postTratta);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }
    public void toTest(){ // serve per spostarmi ad un eventuale nuovo fragment.
        /*Fragment_Sponsor prova = new Fragment_Sponsor();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer,prova);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();*/
    }
}