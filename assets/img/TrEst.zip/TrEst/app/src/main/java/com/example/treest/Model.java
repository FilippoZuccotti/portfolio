package com.example.treest;

import android.content.Context;
import android.util.Log;

import androidx.room.Room;

import com.example.treest.Bacheca.Tratta;
import com.example.treest.Database.AppDatabase;
import com.example.treest.Database.ProfileDatabase;


import com.example.treest.Tratta.Post;

import java.util.ArrayList;
import java.util.List;

public class Model {
    private static  Model ourInstance = null;
    private static  Model dbInstance = null;

    private static ArrayList<Tratta> lista_tratte; // lista delle tratte viene caricata nella SceltaBacheca.
    private static ArrayList<Post> lista_post; // lista dei post viene caricato nella bacheca del singoloPost

    private static AppDatabase postDB =null;

    public static synchronized Model getInstance() {
        if (ourInstance==null)
            ourInstance = new Model();
        return ourInstance;
    }

    public static synchronized Model getInstance(Context context){
        if (dbInstance==null){
            postDB = Room.databaseBuilder(context,AppDatabase.class,"TreEstDB").build();
            dbInstance = new Model();
        }
        return dbInstance;
    }


    private Model() {
        lista_tratte = new ArrayList<>();
        lista_post = new ArrayList<>();
    }

    //----------------------------------------------------------------------------------------------------------------------//
    //Metdoi per le tratte
    public void addTratta(Tratta tratta) throws Exception { lista_tratte.add(tratta); }

    public ArrayList<Tratta> getTratte(){ return lista_tratte; }

    public void removeTratte(){
        lista_tratte.clear();
    }

    public Tratta getTrattaByIndex(int index) { return Model.getInstance().getTratte().get(index); }

    public Tratta getTrattaByDID(int did){
        for(Tratta tratta: lista_tratte){
            if(tratta.getId() == did){
                return tratta;
            }
        }
        return null;
    }
    public int getTratteSize(){ return Model.getInstance().getTratte().size(); }

    //--------------------------------------------------------------------------------------------------------------------//
    // Metodi per i post

    public void addPost(Post post) throws Exception{ lista_post.add(post);}

    public ArrayList<Post> getPost(){return lista_post;}

    public void removePost(){lista_post.clear();}

    public Post getPostByIndex(int index){ return Model.getInstance().getPost().get(index); }

    public int getPostsSize(){return Model.getInstance().getPost().size();}

    public Post getPostByUID(String uid){
        Log.d("Testuid","quello che passo io è:"+uid);
        Log.d("Testuid","lunghezza model"+Model.getInstance().getPostsSize());
        for (Post post : lista_post){

            Log.d("Testuid","uid:"+post.getUid());
            if(post.getUid()== uid){
                Log.d("Testuid","qui ci entro?");
                return post;
            }
        }
        return null;
    }
    //--------------------------------------------------------------------------------------------------------------------//
    //Metodi per il database

    //aggiungere l'immagine profilo al db
    public void addProfileImg(ProfileDatabase image){ postDB.postDAO().addProfileImage(image);}

    public void updateProfileImage (String img,int uid, int pversion){
        postDB.postDAO().updateProfileImage(img,uid,pversion);
    }

    public List<ProfileDatabase> getProfileImage(int uid){
        return postDB.postDAO().getProfileImage(uid);
    }

    public void setPosts (List<Post> posts){

        Log.d("lista_post","posts nel metodo sono"+posts.size());
        lista_post = new ArrayList<>(posts);
        Log.d("lista_post","la lunghezza dentro il metodo è "+lista_post.size());
    }

    //--------------------------------------------------------------------------------------------------------------------------------//










}
