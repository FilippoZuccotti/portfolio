package com.example.treest.Tratta;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.treest.Model;
import com.example.treest.R;

import java.io.File;

public class Adapter extends RecyclerView.Adapter<ViewHolder> {
    private LayoutInflater mInflater;
    private PostTratta listFragment;

    private Context context;

    public Adapter(Context context, PostTratta fragment){
        this.mInflater = LayoutInflater.from(context);
        this.listFragment=fragment;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.single_post,parent,false);

        return new ViewHolder(view,listFragment);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // prendo il post
        Post post = Model.getInstance().getPostByIndex(position);
        String img = post.getImg();

        holder.imgUtente.setImageDrawable(null); // per fissare l'immagine

        // prendo la data del post, non tutta solo il giorno e l'ora.
        String data = post.getData();
        String giorno = data.substring(0,10);
        String ora = data.substring(11,16);


        SharedPreferences sharedPreferences = listFragment.getActivity().getPreferences(Context.MODE_PRIVATE);
        String mineUid = sharedPreferences.getString("UID","");
        Log.d("prova","il mio uid"+mineUid+"mentre l'uid del post è"+post.getUid());


        holder.segui.setOnClickListener(new View.OnClickListener() { // qui gestisco il click sul pulsante per seguire una persona
            @Override
            public void onClick(View view) {
                Log.d("click","hai cliccato sul bottone del post singolo, "+Model.getInstance().getPostByIndex(position).getUid());
                listFragment.follow(Model.getInstance().getPostByIndex(position).getUid(),post.getNome()); // richiamo il metodo dentro postTratta e gli passo lo uid di quel post.
            }
        });

        holder.nonsegui.setOnClickListener(new View.OnClickListener() { // faccio la stesa cosa del follow anche qua
            @Override
            public void onClick(View view) {
                listFragment.unFollow(Model.getInstance().getPostByIndex(position).getUid(),post.nome);
            }
        });

        /* gestisco il click del bottone!!!
        holder.botton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("prova","hai cliccato sul post di :"+post.getNome()+"scritto il:"+post.getData()); // dentro qui posso richiamare un metodo che si trova in prova fragment basta fare listFragment.nomFunzione();
            }
        });*/

        // devo anche modificare la visualizzazine se seguo qualcuno lo sfondo della sua card è di uncolore diverso e il pulsante su cui cliccare cambia.

        if(post.getUid().equals(mineUid)){
            Log.d("primo","sono dentro il mi post");
            holder.segui.setVisibility(View.GONE);
            holder.nonsegui.setVisibility(View.GONE);
        }else {

            if (Model.getInstance().getPostByIndex(position).getFollow() == true) {
                holder.segui.setVisibility(View.GONE);
                holder.cardPost.setCardBackgroundColor(Color.parseColor("#ffffde"));
                holder.nonsegui.setVisibility(View.VISIBLE);
            } else {
                holder.segui.setVisibility(View.VISIBLE);
                holder.cardPost.setCardBackgroundColor(Color.parseColor("#ffffff"));
                holder.nonsegui.setVisibility(View.GONE);
            }
        }
        holder.textNomeUtente.setText("Scritto da: "+post.getNome()+" "+ giorno +" "+ora); // setto il testo


        int stato =post.getStato(); // ora devo prendere lo stato
        String  Sstato="";
        switch(stato) {
            case 0:
                Sstato = "Situazione ideale";
                break;
            case 1:
                Sstato = "Accettabile";
                break;
            case 2:
                Sstato = "Gravi problemi per i passeggieri";
                break;
            default:
                Sstato = "";
        }
        int ritardo = post.getRitardo(); // ora devo prendere il ritartdo
        String Sritardo="";
        switch(ritardo) {
            case 0:
                Sritardo = "In orario";
                break;
            case 1:
                Sritardo = "Ritardo di pochi minuti";
                break;
            case 2:
                Sritardo = "Ritardo di oltre 15 minuti";
                break;
            case 3:
                Sritardo = "Treno soppresso";
                break;
            default:
                Sritardo = "";
        }

        // poi prendo il commento
        // unisco stato commento e ritardo insieme in base a quelli che sono presenti
        String comment ="";
        if (stato >=3 && ritardo >=4){ //ne stato e ritardo sono specificati
             comment = post.getCommento();
        }
        if (stato <3 && ritardo >=4){ //esisto solo stao
             comment = post.getCommento()+'\n'+"Stato: "+Sstato;
        }
        if (ritardo <4 && stato >=3){//esiste solo ritardo
             comment = post.getCommento()+'\n'+"Ritardo: "+Sritardo;
        }
        if (ritardo<4 && stato<3){//post con stato e ritardo
             comment = post.getCommento() +'\n'+"Stato: "+Sstato+'\n'+"Ritardo: "+Sritardo;
        }
        holder.textContenuto.setText(comment); // li setto tutti insieme in un unica textView.

       // setto l'immagine profilo di default
        if(post.getImg() != null) {

            try {
                Log.d("imgBase64", "la foto di " + post.getNome() + "uid:" + post.getUid() + "c'è il suo pid è:" + post.getPversion() + " e finisce per" + post.getImg().substring(post.getImg().length() - 10, post.getImg().length()) + "devo decodificarla il post sta in poszione"+position);
                String base64 = post.getImg();
                byte[] code = Base64.decode(base64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(code, 0, code.length);
                //decodifca
                holder.imgUtente.setImageBitmap(bitmap);// se c'è un immagine allora la setto
            } catch (Exception e) {
                Log.d("Decode imgUtente", "Error while decoding imgUtente: " + e.toString());
                Log.d("imgBase64", "errore nel settare l'immagine di: " + post.getNome() + ":" + post.getUid() + "l'immagine è decodificata male quindi metto quella di default");
                holder.imgUtente.setBackgroundResource(R.drawable.erroreimg);// se l'immagine è sbagliata metyo una foto per far capire che l'immagine è sbagliata
            }
            }else{
            Log.d("imgBase64","non c'è l'immagine di : "+post.getNome()+":"+post.getUid()+" infatti il suo pid è"+ post.getPversion());
            holder.imgUtente.setBackgroundResource(R.drawable.profilo);
        }
    }

    @Override
    public int getItemCount() {
        return Model.getInstance().getPostsSize();
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }


}
