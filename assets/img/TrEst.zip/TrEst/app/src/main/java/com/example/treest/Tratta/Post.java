package com.example.treest.Tratta;

import androidx.annotation.Nullable;

public class Post {
    String uid;
    String pid;
    String nome;
    String pversion;
    String img;
    int ritardo;
    int stato;
    String commento;
    Boolean follow;
    String data;

    public Post(String uid, String pid, @Nullable String nome, String pversion, @Nullable String img, @Nullable int ritardo,@Nullable int stato, @Nullable String commento,Boolean follow,String data) {
        this.uid = uid;
        this.pid = pid;
        this.nome = nome;
        this.pversion = pversion;
        this.img = img;
        this.ritardo = ritardo;
        this.stato = stato;
        this.commento = commento;
        this.follow=follow;
        this.data=data;
    }

    public String getUid() { return uid; }

    public void setUid(String uid) { this.uid = uid; }

    public String getPid() { return pid; }

    public void setPid(String pid) { this.pid = pid; }

    public String getNome() { return nome; }

    public void setNome(String nome) { this.nome = nome; }

    public String getPversion() { return pversion; }

    public void setPversion(String pversion) { this.pversion = pversion; }

    public String getImg() { return img; }

    public void setImg(String img) { this.img = img; }

    public int getRitardo() { return ritardo; }

    public void setRitardo(int ritardo) { this.ritardo = ritardo; }

    public int getStato() { return stato; }

    public void setStato(int stato) { this.stato = stato; }

    public String getCommento() { return commento; }

    public void setCommento(String commento) { this.commento = commento; }

    public Boolean getFollow() { return follow; }

    public void setFollow(Boolean follow) { this.follow = follow;}

    public String getData() { return data; }

    public void setData(String data) { this.data = data; }
}
