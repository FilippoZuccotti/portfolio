function caricafile(){

if(localStorage.getItem("ristoranti")==null){
  localStorage.setItem("ristoranti", JSON.stringify(ristoranti));
}
if(localStorage.getItem("dolci")==null){
  localStorage.setItem("dolci", JSON.stringify(dolci));
}
if(localStorage.getItem("cibi")==null){
  localStorage.setItem("cibi", JSON.stringify(cibi));
}
if(localStorage.getItem("bevande")==null){
  localStorage.setItem("bevande", JSON.stringify(bevande));
}
if(localStorage.getItem("clienti")==null){
  localStorage.setItem("clienti", JSON.stringify(clienti));
}
if(localStorage.getItem("sessione")==null){
  localStorage.setItem("sessione", JSON.stringify(sessione));
}

}


function caricaProdotti(){
setTimeout(function caricaProdottir(){

    var ristoranti=localStorage.getItem("ristoranti");
    var ristoranti=JSON.parse(ristoranti);

    for (var i=0;i<ristoranti.length;i++){
        var j=i+1;
        document.getElementById("risto"+i).innerHTML = "<div class='row'> <div class='col-sm-4'> <div class='w3-container  w3-allerta'><p class='w3-xxxlarge'>"+ristoranti[i].ristorante+"<p id='stelle'></p>"+
            "</div> </div> <div class='col-sm-6'> <p>Titolare: "+ristoranti[i].nome+" "+ristoranti[i].cognome+"</p>"+
            "<p> Indirizzo: "+ristoranti[i].indirizzo+"<span class='glyphicon glyphicon-map-marker'></span></p>"+
            "<p> Partita iva: "+ristoranti[i].iva +" <span class='glyphicon glyphicon-credit-card'></span></p>"+
            "<p> Contatti: "+ristoranti[i].numero +" <span class='glyphicon glyphicon-phone-alt'></span></p>"+
            "</div> <div class='col-sm-2'> <a href='ristorante.html?"+ i + "'><button class='btn' type='submit'>Visita</button></a> </div></div><hr> <span id='risto"+j+"'></span>";
    }
},300)
}

function controllaR(){
    var nome= document.risto.nome.value;
    var cognome= document.risto.cognome.value;
    var ristorante= document.risto.ristorante.value;
    var indirizzo= document.risto.indirizzo.value;
    var iva= document.risto.iva.value;
    var numero=document.risto.numero.value;
    var password = document.risto.password.value;
    var mail = document.risto.mail.value;

    if(nome=="" || cognome=="" || ristorante==""){
        alert("errore campi mancanti");
    }else if(iva.length!=11){
        alert("Iva di lunghezza sbagliata di lunghezza sbagliata");
    }else if(password.length<6){
        alert("Password Troppo corta");
    }else if(numero.length!=10){
        alert("Numero sbagliato");
    }else if(!validazione_email(mail)){
        alert("mail non corretta");
    }else{
        alert("dati corretti prosegui con la registrazione!");
        document.getElementById('bottone').innerHTML = "<button type='button' class='btn btn-info' data-toggle='collapse' data-target='#demo' >Prosegui</button>"

    }

}


function aggiungiRistorante(){
    var ristoranti=localStorage.getItem("ristoranti");
    var ristoranti=JSON.parse(ristoranti);
    var dolci=localStorage.getItem("dolci");
    var dolci=JSON.parse(dolci);
    var cibi=localStorage.getItem("cibi");
    var cibi=JSON.parse(cibi);
    var bevande=localStorage.getItem("bevande");
    var bevande=JSON.parse(bevande);
    var id= ristoranti.length;
    var nome= document.risto.nome.value;
    var cognome= document.risto.cognome.value;
    var ristorante= document.risto.ristorante.value;
    var indirizzo= document.risto.indirizzo.value;
    var iva= document.risto.iva.value;
    var numero=document.risto.numero.value;
    var password = document.risto.password.value;
    var mail = document.risto.mail.value;

    var nuovo={
        "id":id,
        "nome": nome,
        "cognome": cognome,
        "ristorante": ristorante,
        "indirizzo": indirizzo,
        "numero": numero,
        "iva": iva,
        "mail": mail,
        "password":password,
        "cibi":[],
        "bevande":[],
        "dolci":[],
        "recensioni":[],
        "ordini":[]
    }


    // carica i dolci selezionati dal menu

    if(document.dolci0.prova0.checked){
        nuovo.dolci.push(0);

    }
    if(document.dolci1.prova1.checked){
        nuovo.dolci.push(1);
    }
    if(document.dolci2.prova2.checked){
        nuovo.dolci.push(2);
    }
    if(document.dolci3.prova3.checked){
        nuovo.dolci.push(3);
    }

    // carica i cibi selezionati dal menu

    if(document.cibi0.prova0.checked){
        nuovo.cibi.push(0);

    }
    if(document.cibi1.prova1.checked){
        nuovo.cibi.push(1);

    }
    if(document.cibi2.prova2.checked){
        nuovo.cibi.push(2);

    }
    if(document.cibi3.prova3.checked){
        nuovo.cibi.push(3);

    }
    if(document.cibi4.prova4.checked){
        nuovo.cibi.push(4);

    }
    if(document.cibi5.prova5.checked){
        nuovo.cibi.push(5);

    }

    //carica le bevande selezionate dal menu

    if(document.bevande0.prova0.checked){
        nuovo.bevande.push(0);

    }
    if(document.bevande1.prova1.checked){
        nuovo.bevande.push(1);

    }
    if(document.bevande2.prova2.checked){
        nuovo.bevande.push(2);

    }
    if(document.bevande3.prova3.checked){
        nuovo.bevande.push(3);

    }
    if(document.bevande4.prova4.checked){
        nuovo.bevande.push(4);

    }
    if(document.bevande5.prova5.checked){
        nuovo.bevande.push(5);

    }

    ristoranti.push(nuovo);
    localStorage.setItem("ristoranti", JSON.stringify(ristoranti));

    alert("ristorante aggiunto")
    window.location.href = "index.html";



}



function menudolci(){
    var dolci=localStorage.getItem("dolci");
    var dolci=JSON.parse(dolci);
    document.write("<div class='row'>")
    for (var i=0;i<dolci.length;i++){
        document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+dolci[i].sorgentefoto+" style='width:100%'><p>"+dolci[i].nome+"<form name='dolci"+i+"'><input type='checkbox' name='prova"+i+"'></form></div></div></div>")

    }
    document.write("</div>")

}

function menucibi(){
    var cibi=localStorage.getItem("cibi");
    var cibi=JSON.parse(cibi);
document.write("<div class='row'>")
    for (var i=0;i<4;i++){
        document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"<form name='cibi"+i+"'><input type='checkbox' name='prova"+i+"'></form></div></div></div>")
    }
    document.write("</div>")
    document.write("<div class='row'>")
    for (var i=4;i<cibi.length;i++){
        document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"<form name='cibi"+i+"'><input type='checkbox' name='prova"+i+"'></form></div></div></div>")
    }
    document.write("</div>")
}

function menubevande(){
    var bevande=localStorage.getItem("bevande");
    var bevande=JSON.parse(bevande);
    document.write("<div class='row'>")
    for (var i=0;i<4;i++){
        document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"<form name='bevande"+i+"'><input type='checkbox' name='prova"+i+"'></form></div></div></div>")
    }
        document.write("</div>")
        document.write("<div class='row'>")
    for (var i=4;i<bevande.length;i++){
        document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"<form name='bevande"+i+"'><input type='checkbox' name='prova"+i+"'></form></div></div></div>")
    }
        document.write("</div>")
}







    function caricaRistorante(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var id = window.location.search.substring(1);
        document.getElementById('risto').innerHTML = ristoranti[id].ristorante
        }


    function cibiRistorante(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var cibi=localStorage.getItem("cibi");
        var cibi=JSON.parse(cibi);
        var id = window.location.search.substring(1);
        var ristorante = ristoranti[id];
        var n = ristorante.cibi.length;

        for(var i=0;i<n;i++){
            document.write("<div class='card card-body  row'><img src="+cibi[ristorante.cibi[i]].sorgentefoto+" style='width:30%; height:30%'' align='left'><p>"+cibi[ristorante.cibi[i]].nome+" "+cibi[ristorante.cibi[i]].prezzo +"&euro;<br></p><a href='prodotto.html?c"+cibi[ristorante.cibi[i]].id+"r"+id+"'><button type='button' class='btn btn-outline-primary'>+Carrello</button></a></div><hr>")
        }
    }

    function bevandeRistorante(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var bevande=localStorage.getItem("bevande");
        var bevande=JSON.parse(bevande);
        var id = window.location.search.substring(1);
        var ristorante = ristoranti[id];
        var n = ristorante.bevande.length;

        for(var i=0;i<n;i++){
            document.write("<div class='card card-body  row'><img src="+bevande[ristorante.bevande[i]].sorgentefoto+" style='width:30%; height:30%'' align='left'><p>"+bevande[ristorante.bevande[i]].nome+" "+bevande[ristorante.bevande[i]].prezzo +"&euro;<br></p> <a href='prodotto.html?b"+bevande[ristorante.bevande[i]].id+"r"+id+"'><button type='button' class='btn btn-outline-primary'>+Carrello</button></a></div><hr>")
        }

    }

    function dolciRistorante(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var dolci=localStorage.getItem("dolci");
        var dolci=JSON.parse(dolci);
        var id = window.location.search.substring(1);
        var ristorante = ristoranti[id];
        var n = ristorante.dolci.length;
        for(var i=0;i<n;i++){
            document.write("<div class='card card-body  row'><img src="+dolci[ristorante.dolci[i]].sorgentefoto+" style='width:30%; height:30%'' align='left'><p>"+dolci[ristorante.dolci[i]].nome+" "+dolci[ristorante.dolci[i]].prezzo +"&euro;<br></p> <a href='prodotto.html?d"+dolci[ristorante.dolci[i]].id+"r"+id+"'><button type='button' class='btn btn-outline-primary'>+Carrello</button></a></div><hr>")
        }
    }

    function commenta(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var sessione=localStorage.getItem("sessione");
        var sessione=JSON.parse(sessione);
        var id = window.location.search.substring(1);
        var voto = document.recensione.myRange.value;
        var ristorante = ristoranti[id];

        if (sessione.length>0){
            if(sessione[0].ristorante==undefined){

                var rece= document.recensione.commento.value;
                var recensione={
                    "commento":rece,
                    "voto": voto,
                }

                if (rece==""){
                    alert("devi scrivere qualcosa nella recensione")
                }else{
                ristorante.recensioni.push(recensione);
                localStorage.setItem("ristoranti", JSON.stringify(ristoranti));
                alert("recensione aggiunta");
                location.reload();
            }
            }else{
                alert(" non puoi aggiungere una recensione se hai un ristorante");
            }

    }else{
        alert(" non puoi aggiungere una recensione se non sei registrato");
    }
}

    function caricaRecensioni(){
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);

        var id = window.location.search.substring(1);
        var ristorante = ristoranti[id];
        var n = ristorante.recensioni.length;
        if (n==0){
            document.write("<div class='row contenitore'><div class='w3-card-4 rece'><p class='testo'>Non ci sono recensioni su questo ristorante</p></div></div>");
        }else{

            for( var i=0;i<n;i++){
                document.write("<div class='row contenitore'><div class='w3-card-4 rece'><p class='testo'>"+ristorante.recensioni[i].commento+"</p><br><p class='testo'>Votazione:"+ristorante.recensioni[i].voto+"</p></div></div>");

            }
        }
    }


    function infoCibi(){

        var cibi=localStorage.getItem("cibi");
        var cibi=JSON.parse(cibi);
        var bevande=localStorage.getItem("bevande");
        var bevande=JSON.parse(bevande);
        var dolci=localStorage.getItem("dolci");
        var dolci=JSON.parse(dolci);

        var id = window.location.search.substring(1);
        var d = window.location.search.substring(2);
        p=d[0]

        var c = window.location.search.substring(3);

        if(id[0]=='c'){
            document.write("<div class='col-md-6'><div class='w3-card-4'><img src="+cibi[p].sorgentefoto+" style='width:100%'></div></div><div class='col-md-4'><div class='w3-container  w3-lobster'><p class='w3-xxxlarge'>"+cibi[p].nome+" "+cibi[p].prezzo+"&euro;</p></div><h3>ingredienti</h3><p>"+ cibi[p].ingredienti +"</p><h3>Descrizione</h3><p>"+ cibi[p].descrizione +"</p>"+
                        "</div>" )
        }else if(id[0]=='b'){
            document.write("<div class='col-md-6'><div class='w3-card-4'><img src="+bevande[p].sorgentefoto+" style='width:50%'></div></div><div class='col-md-4'><div class='w3-container  w3-lobster'><p class='w3-xxxlarge'>"+bevande[p].nome+" "+bevande[p].prezzo+"&euro;</p></div>"+
                        "</div>" )
        }else{
            document.write("<div class='col-md-6'><div class='w3-card-4'><img src="+dolci[p].sorgentefoto+" style='width:100%'></div></div><div class='col-md-4'><div class='w3-container  w3-lobster'><p class='w3-xxxlarge'>"+dolci[p].nome+" "+dolci[p].prezzo+"&euro;</p></div><h3>ingredienti</h3><p>"+ dolci[p].ingredienti +"</p><h3>Descrizione</h3><p>"+ dolci[p].descrizione +"</p>"+
                        "</div>" )
        }
        if(c[0]=="r"){
            document.write("<div class='col-md-2'><br><form name='quantita'><input type='number' id='ordine'  value='1' min='0' max='10' step='1'> <input type='button' id='carrello' onclick='aggiungiaCarrello()' value='+ carrello'></form></div>")
        }else{
            document.write("<div class='col-md-2'><br><h4>Cercalo nei negozi</h4></div>")
        }

    }


    function validazione_email(email) {
      var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
      if (!reg.test(email)) return false; else return true;
    }

//registrazione cliente
    function aggiungiCliente(){
        var clienti=localStorage.getItem("clienti");
        var clienti=JSON.parse(clienti);

        var id= clienti.length;
        var nome= document.cliente.nome.value;
        var cognome= document.cliente.cognome.value;
        var mail= document.cliente.mail.value;
        var nascita= document.cliente.nascita.value;
        var codice= document.cliente.codice.value;
        var numero= document.cliente.numero.value;
        var pagamento= document.cliente.pagamento.value;
        var password= document.cliente.password.value;
        var interesse = document.cliente.interesse.value





        if(nome=="" || cognome=="" || nascita==""){
            alert("errore campi mancanti");
        }else if(codice.length!=16){
            alert("Codice Fiscale di lunghezza sbagliata");
        }else if(password.length<6){
            alert("Password Troppo corta");
        }else if(numero.length!=10){
            alert("Numero sbagliato");
        }else if(!validazione_email(mail)){
            alert("mail non corretta");
        }else{
        var nuovo={
            "id": id,
            "nome": nome,
            "cognome": cognome,
            "mail": mail,
            "nascita": nascita,
            "codiceFiscale": codice,
            "numero": numero,
            "pagamento":pagamento,
            "password":password,
            "interesse":interesse,
            "carrello":[]
        }

        clienti.push(nuovo);
        localStorage.setItem("clienti", JSON.stringify(clienti));
        alert("cliente aggiunto");
        window.location.href = "index.html"

    }
}


//controlla password e email
    function controllaCliente(){
        var clienti=localStorage.getItem("clienti");
        var clienti=JSON.parse(clienti);
        var sessione=localStorage.getItem("sessione");
        var sessione=JSON.parse(sessione);
        var ristoranti=localStorage.getItem("ristoranti");
        var ristoranti=JSON.parse(ristoranti);
        var check=0;
        var mail= document.accedi.mail.value;
        var password = document.accedi.password.value;


        if(document.accedi.ristoratore.checked){
            for(var i=0;ristoranti.length;i++){
                check=0;
                if(mail==ristoranti[i].mail && password==ristoranti[i].password){
                    alert("Bentornato");
                    sessione.push(ristoranti[i]);
                    localStorage.setItem("sessione", JSON.stringify(sessione));
                    location.reload();
                    break;
                }else{
                    check=1
                }
            }
            if(check==1){
                alert("password o mail errati")
            }
        }else{
            for(var i=0;i<clienti.length;i++){
                check=0;
                if(mail==clienti[i].mail && password==clienti[i].password){
                        alert("Bentornato");
                        sessione.push(clienti[i]);
                        localStorage.setItem("sessione", JSON.stringify(sessione));
                        carrello();

                        location.reload();

                        break;
                    }else{
                        check=1
                    }
            }
            if(check==1){
                alert("password o mail errati")
            }
        }
    }



//controlla se c'è qualcuno loggato e modifica la navbar
function accesso(){setTimeout( function accessor(){
        var sessione=localStorage.getItem("sessione");
        var sessione=JSON.parse(sessione);
        if(sessione.length==0){

       document.getElementById("nav4").innerHTML="<a class='dropdown-toggle'  data-toggle='dropdown' href='#'><span class='glyphicon glyphicon-log-in'></span> accedi</a><ul class='dropdown-menu accedi'>"+
                                                    "<form name='accedi'><li><input  type='email' class='form-control' id='mail'  placeholder='mail'> </li><br><li><input  type='password' class='form-control' id='password'  placeholder='password'> </li>"+
                                                    "<br><li><input  type='checkbox' id='ristoratore'>ristoratore</li><br><li><input type='button' onclick='controllaCliente()' value='accedi'></li></form></ul>";


      document.getElementById("nav5").innerHTML="<a class='dropdown-toggle'  data-toggle='dropdown' href='#'><span class='glyphicon glyphicon-user'></span> registrati</a><ul class='dropdown-menu'>"+
                                                "<li><a href='registrazione.html'>Cliente</a></li><li><a href='registrazioneRisto.html'>Ristoratore</a></li></ul>";

        }else{
            if(sessione[0].ristorante==undefined){
            document.getElementById("nav1").innerHTML="<a href='carrello.html'><span class='glyphicon glyphicon-shopping-cart'></span>Carrello</a>";
            document.getElementById("nav2").innerHTML="<a href='profilo.html'><span class='glyphicon glyphicon-user'></span>Profilo</a>";
            document.getElementById("nav3").innerHTML="<a><input type ='button' onclick='esci()' value='Esci'></a>";
        }else {
            document.getElementById("nav2").innerHTML="<a href='profilo.html'><span class='glyphicon glyphicon-user'></span>Profilo</a>";
            document.getElementById("nav3").innerHTML="<a><input type ='button' onclick='esci()' value='Esci'></a>";
        }

        }
    },300)}

// fa il logout del profilo
function esci(){
 var sessione=localStorage.getItem("sessione");
 var sessione=JSON.parse(sessione);
 var clienti=localStorage.getItem("clienti");
 var clienti=JSON.parse(clienti);
 var ristoranti=localStorage.getItem("ristoranti");
 var ristoranti=JSON.parse(ristoranti);
 var id= sessione[0].id;
 if(sessione[0].ristorante==undefined){
     for(var i=0;i<clienti.length;i++){
         if(id==clienti[i].id){
             clienti.splice(i,1,sessione[0]);
             localStorage.setItem("clienti", JSON.stringify(clienti));
             break;
         }
     }
         sessione.splice(0,1);
         localStorage.setItem("sessione", JSON.stringify(sessione));
         alert("logout effettuato!")
}else{
    for(var i=0;i<ristoranti.length;i++){
        if(id==ristoranti[i].id){
            ristoranti.splice(i,1,sessione[0]);
            localStorage.setItem("ristoranti", JSON.stringify(ristoranti));
            break;
        }
    }
    sessione.splice(0,1);
    localStorage.setItem("sessione", JSON.stringify(sessione));
    alert("logout effettuato!")
}

 window.location.href = "index.html";

}


//carica la pagina del profilo
 function vediProfilo(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);

     if(sessione[0].ristorante==undefined){
     document.write("<div class='row'><div class='col-md-6'><div class='w3-card-4' ><div class='w3-container  w3-lobster'><div class='w3-xxxlarge'><p>"+sessione[0].nome+" "+sessione[0].cognome+"</p></div></div>"+
                    "<p class='info'>Mail: "+sessione[0].mail+"<br>Codice Fiscale: "+sessione[0].codiceFiscale+"<br>Numero: "+sessione[0].numero+"<br>Nascita: "+sessione[0].nascita+"<br>Metodo di pagamento: "+sessione[0].pagamento+" </p><div class='info'><a href='modificaC.html'><button type='submit' class='btn btn-primary'>Modifica dati</button></a> "+
                    "<a href='#'><button type='submit' class='btn btn-danger' onclick='elimina()'>cancellaProfilo</button></a></div></div></div>")
    }else{
        var nrece=sessione[0].recensioni.length;

        var voto=0;
        for(var i=0;i<nrece;i++){
            var votazione= parseInt(sessione[0].recensioni[i].voto)
            voto += votazione
        }
        voto= voto/nrece;
        document.write("<div class='row'><div class='col-md-6'><div class='w3-card-4' ><div class='w3-container  w3-lobster'><div class='w3-xxxlarge'><p>"+sessione[0].ristorante+"</p></div></div>"+
                       "<p class='info'>Titolare: "+sessione[0].nome+" "+sessione[0].cognome+"<br>Rating: "+ voto +" <span class='glyphicon glyphicon-star'></span><br>Mail: "+sessione[0].mail+"<br>Numero: "+sessione[0].numero+"<br>Indirizzo: "+sessione[0].indirizzo+"<br>IVA: "+sessione[0].iva+" </p><div class='info'><a href='modificaR.html'><button type='submit' class='btn btn-primary'>Modifica dati</button></a> "+
                       "<a href='#'><button type='submit' class='btn btn-danger' onclick='elimina()'>cancellaProfilo</button></a></div></div></div></div>")
    }
 }
  function vediOrdini(){
      var sessione=localStorage.getItem("sessione");
      var sessione=JSON.parse(sessione);
      var ristoranti=localStorage.getItem("ristoranti");
      var ristoranti=JSON.parse(ristoranti);
      var tempo=0;
      if(sessione[0].ristorante==undefined){
      document.write("<div class='col-md-6'><div class='w3-card-4' ><div class='w3-container  w3-lobster'><div class='w3-xxxlarge'> <p>I tuoi ordini</p></div></div>")
     for(var i=0;i<ristoranti.length;i++){

      if(ristoranti[i].ordini.length>0){

   }
          for(var j=0;j<ristoranti[i].ordini.length;j++){
              if(ristoranti[i].ordini[j][1].cliente==sessione[0].id){
                   document.write("<p class='info' id='ordini'>Il tuo ordine fatto il "+ristoranti[i].ordini[j][(ristoranti[i].ordini[j].length)-1] +" è pronto tra "+(j+1)*3+" min, vieni a ritirarlo al ristorante: "+ristoranti[i].ristorante+" in "+ristoranti[i].indirizzo+"<hr></p>");
               }
          }

      }
  }
      document.write("</div>")


  }








  function interessi(){
      var sessione=localStorage.getItem("sessione");
      var sessione=JSON.parse(sessione);
      var cibi=localStorage.getItem("cibi");
      var cibi=JSON.parse(cibi);
      var bevande=localStorage.getItem("bevande");
      var bevande=JSON.parse(bevande);
      var dolci=localStorage.getItem("dolci");
      var dolci=JSON.parse(dolci);
      var interesse = sessione[0].interesse;

      if(sessione[0].ristorante==undefined){
          if(interesse == "dolci"){
              for(var i=0;i<dolci.length;i++){
                  document.getElementById("interesse").innerHTML += "<div class='info'><div class='w3-card-4' ><div class='row'><div class='col-md-3'><img src='"+dolci[i].sorgentefoto+"' width='100%''></div>"+
                                                                    "<div class='col-md-7 info'> <p class='w3-xlarge'>"+dolci[i].nome+" "+dolci[i].prezzo+"&euro;</p><br><p>"+dolci[i].descrizione+"</p></div><div class='col-md-2 info'>"+
                                                                    "<a href='prodotto.html?d"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></div></div></div></div>";
              }
          }else if(interesse == "bevande"){
              for(var i=0;i<bevande.length;i++){
                  document.getElementById("interesse").innerHTML += "<div class='info'><div class='w3-card-4' ><div class='row'><div class='col-md-3'><img src='"+bevande[i].sorgentefoto+"' width='50%''></div>"+
                                                                    "<div class='col-md-7 info'> <p class='w3-xlarge'>"+bevande[i].nome+" "+bevande[i].prezzo+"&euro;</p></div><div class='col-md-2 info'>"+
                                                                    "<a href='prodotto.html?b"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></div></div></div></div>";
              }
          }else if(interesse == "cibi"){
              for(var i=0;i<cibi.length;i++){
                  document.getElementById("interesse").innerHTML += "<div class='info'><div class='w3-card-4' ><div class='row'><div class='col-md-3'><img src='"+cibi[i].sorgentefoto+"' width='100%''></div>"+
                                                                    "<div class='col-md-7 info'> <p class='w3-xlarge'>"+cibi[i].nome+" "+cibi[i].prezzo+"&euro;</p><br><p>"+cibi[i].descrizione+"</p></div><div class='col-md-2 info'>"+
                                                                    "<a href=''prodotto.html?c"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></div></div></div></div>";
              }
          }
      }
  }




 function aggiungiaCarrello(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);

     var qta = document.quantita.ordine.value;

     var id = window.location.search.substring(1);
     if(sessione.length>0){
         if(sessione[0].ristorante==undefined){
            var nuovo={
                "cibi":id,
                "cliente":sessione[0].id,
                "quantita":qta
            }
                 alert("aggiunto a carrello");
                 sessione[0].carrello[id[3]].push(nuovo);
                 localStorage.setItem("sessione", JSON.stringify(sessione));
                 window.history.back();
        }else{
            alert("sei un ristoratore non puoi effettuare ordini")
            window.history.back();
        }
 }else{
     alert("devi essere registrato per aggiungere un prodotto")
     window.history.back();
 }
 }


 function caricaCarrello(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);
     var cibi=localStorage.getItem("cibi");
     var cibi=JSON.parse(cibi);
     var bevande=localStorage.getItem("bevande");
     var bevande=JSON.parse(bevande);
     var dolci=localStorage.getItem("dolci");
     var dolci=JSON.parse(dolci);
     var ristoranti=localStorage.getItem("ristoranti");
     var ristoranti=JSON.parse(ristoranti);
     var n= sessione[0].carrello.length;
     var costo=0;

     for(var i=0;i<n;i++){
         for(var j=1;j<sessione[0].carrello[i].length;j++){

                 if(sessione[0].carrello[i][j].cibi[0]=='c'){

                    costo += (cibi[sessione[0].carrello[i][j].cibi[1]].prezzo)*sessione[0].carrello[i][j].quantita;

                }else if(sessione[0].carrello[i][j].cibi[0]=='b'){
                    costo += (bevande[sessione[0].carrello[i][j].cibi[1]].prezzo)*sessione[0].carrello[i][j].quantita;
                }else{
                    costo += (dolci[sessione[0].carrello[i][j].cibi[1]].prezzo)*sessione[0].carrello[i][j].quantita;
                }
    }
}


     for(var i=0;i<n;i++){

         for(var j=1;j<sessione[0].carrello[i].length;j++){

                 if(sessione[0].carrello[i][j].cibi[0]=='c'){

                 document.write("<div class='info'><div class='w3-card-4'><div class='row'><div class='col-xs-3 info'><img src='"+cibi[sessione[0].carrello[i][j].cibi[1]].sorgentefoto+"' width='100%'>"+
                                "</div><div class='col-xs-5 info'><p>"+cibi[sessione[0].carrello[i][j].cibi[1]].nome+" X "+sessione[0].carrello[i][j].quantita +"</p><p>Ristorante: "+ristoranti[sessione[0].carrello[i][j].cibi[3]].ristorante+"</p></div><div class='col-xs-2 info'></div></div></div></div>"
                            );
             }else if(sessione[0].carrello[i][j].cibi[0]=='b'){
                 document.write("<div class='info'><div class='w3-card-4'><div class='row'><div class='col-xs-3 info'><img src='"+bevande[sessione[0].carrello[i][j].cibi[1]].sorgentefoto+"' width='50%'>"+
                                "</div><div class='col-xs-5 info'><p>"+bevande[sessione[0].carrello[i][j].cibi[1]].nome+" X "+sessione[0].carrello[i][j].quantita +"</p><p>Ristorante: "+ristoranti[sessione[0].carrello[i][j].cibi[3]].ristorante+"</p></div><div class='col-xs-2 info'></div></div></div></div>");
             }else{
                 document.write("<div class='info'><div class='w3-card-4'><div class='row'><div class='col-xs-3 info'><img src='"+dolci[sessione[0].carrello[i][j].cibi[1]].sorgentefoto+"' width='100%'>"+
                                "</div><div class='col-xs-5 info'><p>"+dolci[sessione[0].carrello[i][j].cibi[1]].nome+" X "+sessione[0].carrello[i][j].quantita +"</p><p>Ristorante: "+ristoranti[sessione[0].carrello[i][j].cibi[3]].ristorante+"</p></div><div class='col-xs-2 info'></div></div></div></div>");
     }
    }

 }

 document.write("<div class='info'><div class='w3-card-4'><div class='row'><div class='col-xs-8 info'><p>Totale:......"+costo+"&euro;</p>"+
                "</div><div class='col-xs-2 info'><button onclick='paga()'type='button' class='btn btn-primary'>Paga</button></div></div></div></div>");






}


 function paga(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);
     var ristoranti=localStorage.getItem("ristoranti");
     var ristoranti=JSON.parse(ristoranti);
     var tempo=0;
     var n= sessione[0].carrello.length;
     var carrello= sessione[0].carrello;
     var data = new Date();
     var gg=data.getDate();
     var mm=data.getMonth()+1;
     var aa= data.getFullYear();
     var hh= data.getHours();
     var min= data.getMinutes();
    // var q= sessione[0].ordini.length;

     cae=gg+"/"+mm+"/"+aa+" "+hh+":"+min

     for(var i=0;i<n;i++){
             tempo += (sessione[0].carrello[i].quantita)*2;
     }
     if(sessione[0].carrello.length==0){
         alert("non ci sono elementi nel carrello")
     }else{

         for(var i=0;i<sessione[0].carrello.length;i++){

             if(sessione[0].carrello[i].length>1){
                 sessione[0].carrello[i].push(cae)
                ristoranti[i].ordini.push(sessione[0].carrello[i]);

            }
         }

         localStorage.setItem("ristoranti", JSON.stringify(ristoranti));

         alert("pagamento effettuato");
        localStorage.setItem("sessione", JSON.stringify(sessione));
        location.reload();
        cancellaCarrello();
        window.location.href="profilo.html"


     }
 }

function cancellaCarrello(){
    var sessione=localStorage.getItem("sessione");
    var sessione=JSON.parse(sessione);
         sessione[0].carrello.splice(0,sessione[0].carrello.length);
         localStorage.setItem("sessione", JSON.stringify(sessione));

         carrello();

}

function carrello(){
    var sessione=localStorage.getItem("sessione");
    var sessione=JSON.parse(sessione);
    var ristoranti=localStorage.getItem("ristoranti");
    var ristoranti=JSON.parse(ristoranti);
    var car= ristoranti.length-sessione[0].carrello.length;


        for(var i=0;i<car;i++){
            var nuovo=[{

            }];
            sessione[0].carrello.push(nuovo);
        }
        localStorage.setItem("sessione", JSON.stringify(sessione));
}






 function caricamodificaC(){
      var sessione=localStorage.getItem("sessione");
      var sessione=JSON.parse(sessione);


      var nome= sessione[0].nome;
      var cognome= sessione[0].cognome;
      var mail= sessione[0].mail;
      var codice= sessione[0].codiceFiscale;
      var numero= sessione[0].numero;
      var pagamento= sessione[0].pagamento;
      var password= sessione[0].password;
      var interesse = sessione[0].interesse;
      document.getElementById('nome').value= nome;
      document.getElementById('cognome').value= cognome;
      document.getElementById('mail').value= mail;

      document.getElementById('codice').value= codice;
      document.getElementById('numero').value= numero;
      document.getElementById('password').value= password;
      document.getElementById('pagamento').value= pagamento;
       document.getElementById('interesse').value= interesse;
 }

 function modificaC(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);

     var nome= document.cliente.nome.value;
     var cognome= document.cliente.cognome.value;
     var mail= document.cliente.mail.value;
     var codice= document.cliente.codice.value;
     var numero= document.cliente.numero.value;
     var pagamento= document.cliente.pagamento.value;
     var interesse= document.cliente.interesse.value;
     var password= document.cliente.password.value;

     if(nome=="" || cognome==""){
         alert("errore campi mancanti");
     }else if(codice.length!=16){
         alert("Codice Fiscale di lunghezza sbagliata");
     }else if(password.length<6){
         alert("Password Troppo corta");
     }else if(numero.length!=10){
         alert("Numero sbagliato");
     }else if(!validazione_email(mail)){
         alert("mail non corretta");
     }else{


     var nuovo={
         "id": sessione[0].id,
         "nome": nome,
         "cognome": cognome,
         "mail": mail,
         "nascita": sessione[0].nascita,
         "codiceFiscale": codice,
         "numero": numero,
         "pagamento":pagamento,
         "password":password,
         "carrello":sessione[0].carrello,
         "interesse": interesse

     }
      sessione.splice(0,1,nuovo);
      localStorage.setItem("sessione", JSON.stringify(sessione));
      alert("profilo aggiornato");
      window.location.href = "profilo.html";
 }
}

function controllaSessione(){
    var sessione=localStorage.getItem("sessione");
    var sessione=JSON.parse(sessione);
    if(sessione.length>0){
        alert("sei gia loggato non puoi accedere a questa pagina")
        window.location.href="index.html";
    }
}


function caricaModificaR(){
    var sessione=localStorage.getItem("sessione");
    var sessione=JSON.parse(sessione);
    var nome= sessione[0].nome;
    var cognome= sessione[0].cognome;
    var mail= sessione[0].mail;
    var ristorante = sessione[0].ristorante;
    var iva =sessione[0].iva;
    var numero =sessione[0].numero;
    var password =sessione[0].password;
    var indirizzo = sessione[0].indirizzo;

    document.getElementById('nome').value= nome;
    document.getElementById('cognome').value= cognome;
    document.getElementById('mail').value= mail;
    document.getElementById('numero').value= numero;
    document.getElementById('password').value= password;
    document.getElementById('iva').value= iva;
    document.getElementById('ristorante').value= ristorante;
    document.getElementById('indirizzo').value= indirizzo;
}


function modificaR(){
    var sessione=localStorage.getItem("sessione");
    var sessione=JSON.parse(sessione);
    var nome= document.risto.nome.value;
    var cognome= document.risto.cognome.value;
    var mail= document.risto.mail.value;
    var numero= document.risto.numero.value;
    var password= document.risto.password.value;
    var iva= document.risto.iva.value;
    var ristorante= document.risto.ristorante.value;
    var indirizzo= document.risto.indirizzo.value;

    if(nome=="" || cognome=="" || ristorante==""){
        alert("errore campi mancanti");
    }else if(iva.length!=11){
        alert("Codice Fiscale di lunghezza sbagliata");
    }else if(password.length<6){
        alert("Password Troppo corta");
    }else if(numero.length!=10){
        alert("Numero sbagliato");
    }else if(!validazione_email(mail)){
        alert("mail non corretta");
    }else{


    var nuovo={
        "id": sessione[0].id,
        "nome": nome,
        "cognome": cognome,
        "mail": mail,
        "ristorante": ristorante,
        "iva": iva,
        "numero": numero,
        "indirizzo":indirizzo,
        "password":password,
        "recensioni":sessione[0].recensioni,
        "cibi":sessione[0].cibi,
        "bevande":sessione[0].bevande,
        "dolci":sessione[0].dolci,
        "ordini":sessione[0].ordini


    }
     sessione.splice(0,1,nuovo);
     localStorage.setItem("sessione", JSON.stringify(sessione));
     alert("profilo aggiornato");
     window.location.href = "profilo.html";
}
}

 function elimina(){
     var sessione=localStorage.getItem("sessione");
     var sessione=JSON.parse(sessione);
     var clienti=localStorage.getItem("clienti");
     var clienti=JSON.parse(clienti);
     var ristoranti=localStorage.getItem("ristoranti");
     var ristoranti=JSON.parse(ristoranti);
     var id = sessione[0].id;
     if(sessione[0].ristorante==undefined){
         for(var i=0;i<clienti.length;i++){
             if(id==clienti[i].id){
                 clienti.splice(i,1);
                 localStorage.setItem("clienti", JSON.stringify(clienti));
                 break;
             }
         }

/*        sessione.splice(0,1);
        localStorage.setItem("sessione", JSON.stringify(sessione));
        alert("Profilo Eliminato!")
    window.location.href = "index.html";*/
}else{
    for(var i=0;i<ristoranti.length;i++){
        if(id==ristoranti[i].id){
            ristoranti.splice(i,1);
            localStorage.setItem("ristoranti", JSON.stringify(ristoranti));
            break;
        }
    }
}
    sessione.splice(0,1);
    localStorage.setItem("sessione", JSON.stringify(sessione));
    alert("Profilo Eliminato!")
    window.location.href = "index.html";
 }



  function menu(){
       var id = window.location.search.substring(1);
       var cibi=localStorage.getItem("cibi");
       var cibi=JSON.parse(cibi);
       var bevande=localStorage.getItem("bevande");
       var bevande=JSON.parse(bevande);
       var dolci=localStorage.getItem("dolci");
       var dolci=JSON.parse(dolci);
       if(id==0){
           document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Cibi e contorni</p></div></div>")

           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"</div><center><a href='prodotto.html?c"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
           document.write("<div class='row'>")
           for (var i=4;i<cibi.length;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"</div><center><a href='prodotto.html?c"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
       }else if(id==1){
            document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Bevande</p></div></div>")
           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"</div><center><a href='prodotto.html?b"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
           document.write("<div class='row'>")
           for (var i=4;i<bevande.length;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"</div><center><a href='prodotto.html?b"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
       }else if(id==2){
            document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Dolci</p></div></div>")
           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+dolci[i].sorgentefoto+" style='width:100%'><p>"+dolci[i].nome+"</div><center><a href='prodotto.html?d"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
       }else{
            document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Cibi e contorni</p></div></div>")
           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"</div><center><a href='prodotto.html?c"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
           document.write("<div class='row'>")
           for (var i=4;i<cibi.length;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+cibi[i].sorgentefoto+" style='width:100%'><p>"+cibi[i].nome+"</div><center><a href='prodotto.html?c"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
            document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Bevande</p></div></div>")
           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"</div><center><a href='prodotto.html?b"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
           document.write("<div class='row'>")
           for (var i=4;i<bevande.length;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+bevande[i].sorgentefoto+" style='width:50%'><p>"+bevande[i].nome+"</div><center><a href='prodotto.html?b"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
           }
           document.write("</div>")
            document.write(" <div class='w3-container  w3-center w3-allerta'><div class='w3-xxxlarge'><p>Dolci</p></div></div>")
           document.write("<div class='row'>")
           for (var i=0;i<4;i++){
               document.write("<div class='col-md-3 info '> <div class='w3-card-4'> <div class='w3-container  w3-center w3-lobster'><img src="+dolci[i].sorgentefoto+" style='width:100%'><p>"+dolci[i].nome+"</div><center><a href='prodotto.html?d"+i+"'><button type='button' class='btn btn-primary'>Info</button></a></center><br></div></div>")
                }
                document.write("</div>")
  }
}
