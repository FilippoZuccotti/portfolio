import {useNavigate} from "react-router-dom";
import {useState} from "react";
import { FaSearch } from "react-icons/fa";

function Header(){

    const [inputValue,setInputValue] = useState('');
    const navigate = useNavigate()
    const handleSearchClick = () => {
        if(inputValue ==""){
            alert("completa il campo!")
        }else {
            navigate('/cerca/' + inputValue)
        }
    };
    const backHome = () =>{
        navigate('/')

    }

    const change = event =>{
        setInputValue(event.target.value);
    }
    return(
        <div className="container-fluid menu" style={{height:"10vh",backgroundColor:"darkslategray"}}>
            <div className="row flex-row h-100 justify-content-between" style={{width:"90%",margin:"auto"}}>
                <div className="col-2 ps-0 d-flex align-items-center">
                    <h3 className="text-white" style={{fontFamily:"",cursor:"pointer"}} onClick={backHome}>ReactFilm</h3>
                </div>
                <div className="col-8 col-md-6  d-flex justify-content-end pe-0 align-items-center">
                    <div className="">
                        <input type="text"  style={{borderTopLeftRadius:"20px", borderBottomLeftRadius:"20px", height:"40px",paddingLeft:"20px",border:"0px",width:"75%"}} value={inputValue} placeholder={"Cerca un film..."} onChange={change}/>
                        <button onClick={handleSearchClick} style={{borderTopRightRadius:"20px", borderBottomRightRadius:"20px",border:"none",height:"40px",paddingRight:"10px",backgroundColor:"royalblue",color:"white",width:"25%"}}>
                            <FaSearch />
                        </button>
                    </div>
                </div>
            </div>
        </div>


    );
}
export default Header;