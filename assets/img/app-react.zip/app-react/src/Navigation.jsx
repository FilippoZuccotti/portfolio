import {useState} from "react";
import {MdOutlineKeyboardDoubleArrowLeft, MdOutlineKeyboardDoubleArrowRight} from "react-icons/md";
import Grid from "./Grid.jsx";
function Navigation({info,buttonClick,backClick,cerca}){

    let a;
    const [inputValue,setInputValue] = useState('');

    const change = event =>{
        setInputValue(event.target.value);
    }
    function check(){



        if( info==1){
             a =<div className="row">
                <div className="col-2 offset-10 py-3 pe-1">
                    <div className="bottone" onClick={buttonClick} style={{textAlign: "center",color:"white",cursor:"pointer"}}>
                        <MdOutlineKeyboardDoubleArrowRight />
                    </div>
                </div>
             </div>
            return a;

        }else{
            a = <div className="row justify-content-between">
                <div className="col-2  py-3 ps-1">
                    <div className="bottone" onClick={backClick} style={{textAlign: "center",color:"white",cursor:"pointer"}}>
                        <MdOutlineKeyboardDoubleArrowLeft />
                    </div>
                </div>
                <div className="col-md-3 col-6  py-3 text-center">
                    <input style={{height:"5vh", border:"0px",width:"75%"}} type={"number"} placeholder="Pagina..." onChange={change}/>
                    <button style={{height:"5vh",border:"0px",backgroundColor:"royalblue",color:"white", width:"25%"}} onClick={()=>cerca(inputValue)} >Vai</button>
                </div>
                <div className="col-2 py-3 pe-1">
                    <div className="bottone" onClick={buttonClick} style={{textAlign: "center",color:"white",cursor:"pointer"}}>
                        <MdOutlineKeyboardDoubleArrowRight />
                    </div>
                </div>
            </div>
            return a;
        }
    }
    return(
        <>
            {check()}
        </>

    );
}
export default Navigation;