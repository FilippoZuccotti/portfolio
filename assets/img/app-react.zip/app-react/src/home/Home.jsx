import Header from "../Header.jsx";
import Grid from "../Grid.jsx";

function Home() {

    return(<>
            <Header></Header>
            <Grid></Grid>
        </>
    );
}

export default Home