import {useNavigate, useParams} from "react-router-dom";

function Films({data}){
    const navigate = useNavigate()
    const { name } = useParams();
    const handleNavigate = () => {
        navigate('/detail/'+data.id)
    };
    let locandina
    if(data.poster_path == null){
        locandina =  <img src={"../src/assets/locandina.png"} style={{width:"100%",border:"1px solid white",height:"15vh",objectFit:"cover"}}/>
    }else{
        locandina =  <img src={"https://image.tmdb.org/t/p/w500/"+data.poster_path} style={{width:"100%",border:"1px solid white",height:"18vh",objectFit:"cover"}}/>

    }
    return(
        <>
            <div className="row py-0">
                <div className="col-md-1 offset-md-1 col-3 offset-0">
                    {locandina}
                </div>
                <div className="col-md-8 col-7">
                    <p className="titolo" style={{fontSize:"3vh"}}>
                        <span style={{textDecoration:"underline",cursor:"pointer"}} onClick={handleNavigate}>{data.title}</span>
                        <span style={{fontSize:"1.8vh",fontWeight:"lighter",fontFamily:"sans-serif"}}> {data.release_date.slice(0,4)}</span>
                    </p>
                    <p style={{fontWeight:"lighter", color:"lightgray", fontSize:"1.8vh"}}>
                        {data.overview.slice(0,400)}
                    </p>
                </div>
                <div className="col-md-1 col-2">
                    <p>Voto: {data.vote_average}</p>
                </div>
            </div>
            <hr style={{color:"white"}}/>
        </>
    )
}
export default Films;