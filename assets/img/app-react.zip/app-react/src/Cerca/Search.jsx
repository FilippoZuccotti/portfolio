import {useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import Card from "../Card.jsx";
import Films from "./Films.jsx";
import Home from "../home/Home.jsx";
import Header from "../Header.jsx";



function Search(){
    const [films,setFilms] = useState([]);
    const { name } = useParams();
    var lista;
    const check = ()=>{
       if (films.length>0){
           lista = <>
               {films.map((films) => (
                   <Films key={films.id} data={films}></Films>
               ))}
           </>
       }else{
           lista = <>

              <h1>Nessun risultato trovato :(</h1>

           </>
       }
    }

    useEffect(()=>{
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzNTBiNmQ1MWZiNDQ2ZTc2M2RjMmNkOWMwM2E2Yjk0MCIsInN1YiI6IjYwODgxMjQyOWE4YThhMDA0MWZkNTkyNyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.pEA53z23xvnGRNzG3s7NyYVpa6RSpw-ESZadP1-LG2g'
            }
        };





        fetch("https://api.themoviedb.org/3/search/movie?query="+name+"&include_adult=false&language=it-IT&page=1",options)
            .then(res => res.json())
            .then ((json) => {

                    setFilms(json.results);



            })



    }, [name]);
    return(
        <>
            <Header></Header>

            <div className="container">

                <h3 className="py-5 text-white">Ricerca film: "{name}"</h3>
                {check()}
                {lista}
            </div>

        </>
    )
}
export default Search;