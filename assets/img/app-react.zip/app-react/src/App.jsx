import {BrowserRouter, Route, Routes,} from "react-router-dom";


import Detail from "./paginaFilm/Detail.jsx";
import Home from "./home/Home.jsx";
import Search from "./Cerca/Search.jsx";
function App() {
    return(
        <>
            <BrowserRouter>
                <Routes>
                    <Route path='/' element={<Home/>} exact/>
                    <Route path='/detail/:id' element={<Detail/>} />
                    <Route path='/cerca/:name' element={<Search/>} />
                </Routes>
            </BrowserRouter>
        </>
    );
}
export default App
