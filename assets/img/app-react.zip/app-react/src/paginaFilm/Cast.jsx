function Cast({data}){
    let attore;
    if (data.profile_path == null){
       attore =
            <>
                <img src={"../src/assets/profile.jpeg"}/>
                <p className="py-3" style={{textAlign:"center"}}>{data.character}</p>
            </>
    }else{
        attore =
            <>
                <img src={"https://image.tmdb.org/t/p/original/"+data.profile_path}/>
                <p className="py-3" style={{textAlign:"center"}}>{data.character}</p>
            </>

    }

    return(

        <div className="item m-1">
            {attore}
        </div>
    )
}
export default Cast;