import {useNavigate} from "react-router-dom";

function Similar({data}){
    const navigate = useNavigate()
    const handleNavigate = () => {
        navigate('/detail/'+data.id)
    };

    let copertina;

    if( data.poster_path == null){
       copertina =  <img src={"../src/assets/locandina.png"} style={{borderRadius:"0%",width:"12vh",height:"18vh"}}/>
    }else{
        copertina =  <img src={"https://image.tmdb.org/t/p/original/"+data.poster_path} style={{borderRadius:"0%",width:"12vh",height:"18vh"}}/>
    }

    return(
        <>
            <div className="item m-1" style={{cursor:"pointer"}} onClick={handleNavigate}>
                {copertina}
                <p className="py-3" style={{textAlign:"center"}}>{data.title}</p>
            </div>
        </>
    );
}
export default Similar;