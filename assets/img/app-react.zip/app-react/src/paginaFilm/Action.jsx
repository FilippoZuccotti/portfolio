import CIcon from '@coreui/icons-react';

import {cilHeart, cilMovie, cilPlaylistAdd, cilPlus} from "@coreui/icons";
import {useEffect, useState} from "react";
import Cast from "./Cast.jsx";
function Action({data,guarda}){
    const [platform,setPlatform] = useState([]);
    useEffect(()=>{
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzNTBiNmQ1MWZiNDQ2ZTc2M2RjMmNkOWMwM2E2Yjk0MCIsInN1YiI6IjYwODgxMjQyOWE4YThhMDA0MWZkNTkyNyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.pEA53z23xvnGRNzG3s7NyYVpa6RSpw-ESZadP1-LG2g'
            }
        };


        fetch("https://api.themoviedb.org/3/movie/"+guarda+"/watch/providers",options)
            .then(res=>{
                return res.json();
            })
            .then((data)=>{


            })
    }, []);
    return(
        <div className="container-fluid" style={{color:"white", borderRadius:"2px", backgroundColor:"#949292"}}>
            <div className="row">
                <div className="col-12" style={{fontSize:"32px"}}>
                    Voto: {data}
                    <hr/>
                </div>
            </div>
        </div>
    );
}
export default Action;