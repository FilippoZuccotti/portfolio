import {useLocation, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import Cast from "./Cast.jsx";
import Card from "../Card.jsx";
import Action from "./Action.jsx";
import Similar from "./Similar.jsx";
import Header from "../Header.jsx";

function Detail(){
    const location = useLocation();
    const { id } = useParams();
    const [info,setInfo] =useState([]);
    const [img,setImg] = useState("");
    const [cast,setCast] = useState([]);
    const [regista,setRegista] =useState("")
    const [anno,setAnno] =useState("");
    const [genres,setGenres] =useState([]);
    const [similar,setSimiliar] = useState([]);

    function years(){

    }

    useEffect(()=>{
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzNTBiNmQ1MWZiNDQ2ZTc2M2RjMmNkOWMwM2E2Yjk0MCIsInN1YiI6IjYwODgxMjQyOWE4YThhMDA0MWZkNTkyNyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.pEA53z23xvnGRNzG3s7NyYVpa6RSpw-ESZadP1-LG2g'
            }
        };


        fetch("https://api.themoviedb.org/3/movie/"+id+"?language=it-IT",options)
            .then(res=>{
                return res.json();
            })
            .then((data)=>{

                setInfo(data);
                setAnno(info.release_date);
                setGenres(data.genres)
                fetch("https://api.themoviedb.org/3/movie/"+id+"/images",options)
                    .then (res=>{
                        return res.json();
                    })
                    .then((data)=>{
                        console.log(data);
                        setImg(data.backdrops[1].file_path);

                        fetch("https://api.themoviedb.org/3/movie/"+id+"/credits?language=it-IT",options)
                            .then(res=>{
                                return res.json();
                            })
                            .then((data)=>{
                                console.log(data);
                                setCast(data.cast);
                                let regista = data.crew.filter(oggetto => oggetto.job === "Director");
                                setRegista(regista[0].name);

                                fetch("https://api.themoviedb.org/3/movie/"+id+"/similar?language=it-IT&page=1",options)
                                    .then(res=>{
                                        return res.json();
                                    })
                                    .then((data)=>{
                                        setSimiliar(data.results);

                                    })
                            })
                    })
            })

    }, [id]);


    return(
        <>
            <Header></Header>
            <div className="container">
                <div className="row">
                    <div className="col-12 blurred ">
                        <img className="copertina" src={"https://image.tmdb.org/t/p/original/"+img} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 offset-md-1 col-4 offset-0">
                        <img src={"https://image.tmdb.org/t/p/original/"+info.poster_path} style={{width:"100%",objectFit:"cover",border:"1px solid white"}} />
                    </div>
                    <div className="col-md-6 col-8">
                        <p><span className="titolo">{info.title} </span><span className="infos"> {regista} </span><span></span></p>
                        <p className="my-4">{info.overview}</p>
                        <span style={{color:"white"}}>Generi: </span>
                                {genres.map((genres) => (
                                    <span style={{color:"white",fontStyle:"italic", fontWeight:"lighter",fontSize:"12px", backgroundColor:"darkslategray", borderRadius:"2px"}} key={genres.id} className="p-1 mx-1" >{genres.name}</span>
                                ))}
                    </div>
                    <div className="col-md-2 col-8 offset-md-0 offset-4 pt-md-0 pt-3">
                        <Action data={info.vote_average} guarda={id}></Action>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6 offset-md-3 col-12 offset-0 px-0 py-md-0 py-3">
                        <p className="mt-4 px-md-0 px-3">Casting:</p>
                        <div className="container-fluid ">
                            <div className="wrapper m-0">
                                {cast.map((cast) => (
                                    <Cast key={cast.id} data={cast}></Cast>
                                ))}
                            </div>
                        </div>
                        <p className="px-md-0 px-3 m-0">Film simili</p>
                        <hr className="p-0 m-0" style={{color:"darkgray"}}/>
                        <div className="container-fluid px-md-0 px-2">
                            <div className="wrapper m-0">
                                {similar.map((similar) => (
                                    <Similar key={similar.id} data={similar}></Similar>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Detail;