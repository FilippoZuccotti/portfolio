function Footer(){
    return(
        <footer>
            <div className="container-fluid fixed-bottom menu">
                <div className="row">
                    <div className="col-6 d-flex justify-content-center">
                        <p className="p-4">ATP</p>
                    </div>
                    <div className="col-6 col-6 d-flex justify-content-center">
                       <p className="p-4">WTA</p>
                    </div>
                </div>
            </div>

        </footer>
    );
}
export default Footer;