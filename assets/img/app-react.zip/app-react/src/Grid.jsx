import Card from "./Card.jsx";
import {useEffect, useState} from "react";
import Navigation from "./Navigation.jsx";
import Loader from "./Loader.jsx";



function Grid(){
    const[characters,setCharacters] =useState([]);
    const [pagina,setPagina] = useState(1);
    const [loading, setLoading] = useState(true);
    var storage =[];
    const buttonClick = () =>{
        setPagina((prevPagina) => prevPagina +3);
        window.scrollTo({ top: 0, behavior:"instant"});
        console.log(pagina);
    }
    const backClick = () =>{
        setPagina((prevPagina) => prevPagina -3);
        window.scrollTo({ top: 0, behavior:"instant" });
        console.log(pagina);
    }

    const cerca = (p) =>{

        let calcola = (p*3)-2

        setPagina(calcola);
    }



    useEffect(()=>{
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzNTBiNmQ1MWZiNDQ2ZTc2M2RjMmNkOWMwM2E2Yjk0MCIsInN1YiI6IjYwODgxMjQyOWE4YThhMDA0MWZkNTkyNyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.pEA53z23xvnGRNzG3s7NyYVpa6RSpw-ESZadP1-LG2g'
            }
        };
        setLoading(true);

        fetch("https://api.themoviedb.org/3/movie/popular?language=it-IT&page="+pagina+"&region=IT",options)

            .then(res=>{
                setCharacters([]);
                return res.json();
            })
            .then((data)=>{
                console.log(data.results);
                storage = storage.concat(data.results);
                let succ = pagina+1;
                fetch("https://api.themoviedb.org/3/movie/popular?language=it-IT&page="+succ+"&region=IT",options)
                    .then(res=>{
                        return res.json();
                    })
                    .then ((data) =>{
                        storage =storage.concat(data.results);
                        succ++;
                        fetch("https://api.themoviedb.org/3/movie/popular?language=it-IT&page="+succ+"&region=IT",options)
                            .then(res=>{
                                return res.json();
                            })
                            .then((data) =>{
                                storage =storage.concat(data.results);
                                setCharacters(storage);
                                setLoading(false);
                            })
                    })
            })
    }, [pagina]);

    return(

        <div className="container-fluid flex mt-5">

             <div style={{width:"80%",margin: "auto"}}>
                 <h1>Titoli popolari di oggi pagina:{(pagina+2)/3}</h1>
                 <Navigation info={pagina} buttonClick ={buttonClick} backClick={backClick} cerca={cerca}> </Navigation>
                 {loading && <div style={{height:"100vh"}}><Loader></Loader></div>}
                 {!loading && <div className="row flex">
                     {characters.map((character) => (
                         <Card key={character.id} data={character}></Card>
                     ))}
                 </div>}

                <Navigation info={pagina} buttonClick ={buttonClick} backClick={backClick} cerca={cerca}> </Navigation>
            </div>


        </div>
    )
}
export default Grid;