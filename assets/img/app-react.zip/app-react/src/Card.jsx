import {useNavigate} from 'react-router-dom'
/* eslint-disable react/prop-types */
function Card({data}){
    const navigate = useNavigate()


    return(

        <div className="col-md-1 col-3 px-1" onClick={()=>navigate('detail/'+data.id)}>
                <div className="carta my-1 ">
                        <img style={{width:"100%",objectFit:"cover", height:"16vh",border:" solid white"}} src={"https://image.tmdb.org/t/p/w500/"+data.poster_path}/>
                        <div className={"img_description"}><p>{data.title}</p></div>
                </div>
        </div>

    )


}
export default Card;