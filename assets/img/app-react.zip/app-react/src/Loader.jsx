import {Grid, ThreeCircles} from 'react-loader-spinner'

function Loader(){
    return(
        <div className="d-flex container justify-content-center align-items-center vh-100">


        <ThreeCircles
            visible={true}
            height="20vh"
            width="20vh"
            color="royalblue"
            ariaLabel="three-circles-loading"
            wrapperStyle={{}}
            wrapperClass=""
        />
        </div>
    );
}
export default Loader;